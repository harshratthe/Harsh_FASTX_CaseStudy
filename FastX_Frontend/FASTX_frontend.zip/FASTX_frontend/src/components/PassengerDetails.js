import React, { useState, useEffect } from "react";
import { useNavigate, useLocation } from "react-router-dom";
import axios from "axios";
import "../styles/PassengerDetails.css";

const PassengerDetails = () => {
  const navigate = useNavigate();
  const location = useLocation();

  let seats = [];
  let booking = null;

  if (location.state?.seats && location.state?.booking) {
    seats = location.state.seats;
    booking = location.state.booking;
    localStorage.setItem("seats", JSON.stringify(seats));
    localStorage.setItem("booking", JSON.stringify(booking));
    console.log("🔍 booking.route inside PassengerDetails:", booking?.route);

  }
   
  else {
    seats = JSON.parse(localStorage.getItem("seats")) || [];
    booking = JSON.parse(localStorage.getItem("booking")) || null;
  }

  const userId = JSON.parse(localStorage.getItem("user"))?.userId;

  const [passengers, setPassengers] = useState(
    seats.map(() => ({
      fullName: "",
      age: "",
      gender: "",
      phoneNumber: "",
      email: "",
    }))
  );

  const [loading, setLoading] = useState(false);

  useEffect(() => {
    console.log("Booking:", booking);
console.log("Seats:", seats);
console.log("UserId:", userId);

    if (
      !seats.length ||
      !booking ||
      !booking.busId ||
      !booking.route?.origin ||
      !booking.route?.destination ||
      !userId
    ) {
      alert("Missing booking or user information.");
      navigate("/BookSeat");
    }
  }, [seats, booking, userId, navigate]);

  const handleChange = (index, field, value) => {
    const updated = [...passengers];
    updated[index][field] = value;
    setPassengers(updated);
  };

  const proceedToPayment = async () => {
    if (passengers.some(p => !p.fullName || !p.age || !p.gender || !p.phoneNumber || !p.email)) {
      alert("Please fill in all fields.");
      return;
    }

    try {
      setLoading(true);
      const token = localStorage.getItem("token");
      const bookingDate = new Date().toISOString().split("T")[0];
      const totalAmount = booking.fare * seats.length;
    
      const bookingPayload = {
      user: { userId },
      route: { routeId: booking.route.routeId },
      bus: { busId: booking.busId },
      travelDate: booking.travelDate,
      seatNumbers: seats,
      fare: booking.fare,
      totalAmount,
      bookingDate,
      bookingStatus: "CONFIRMED",
      departureTime: booking.departureTime
    };
    console.log("📦 Booking payload:", bookingPayload);



console.log("🔐 Token:", localStorage.getItem("token"));
console.log("🧑‍💼 Role:", localStorage.getItem("role"));



      const bookingResponse = await axios.post(
        "http://localhost:7000/bookings/add",
        {
          user: { userId },
    route: { routeId: booking.route.routeId },
    bus: { busId: booking.busId },
    travelDate: booking.travelDate,
    seatNumbers: seats,
    fare: booking.fare,
    totalAmount,
    bookingDate,
    bookingStatus: "CONFIRMED",
    departureTime: booking.departureTime
        },
        {
          headers: { Authorization: `Bearer ${token}` }
        }
      );

      const savedBooking = bookingResponse.data;
      const bookingId = savedBooking.bookingId;

      for (let i = 0; i < passengers.length; i++) {
        const p = passengers[i];
        await axios.post(
          "http://localhost:7000/passengers/add",
          {
            name: p.fullName,
            age: p.age,
            gender: p.gender,
            seatNumber: seats[i],
            bookingId
          },
          { headers: { Authorization: `Bearer ${token}` } }
        );
      }

      localStorage.setItem("passengers", JSON.stringify(passengers));

      navigate("/payment", {      
        state: {
          booking: {
            bookingId,
            userId,
            route: booking.route,
            travelDate: booking.travelDate,
            departureTime: booking.departureTime,
            busName: booking.busName,
            busType: booking.busType,
            fare: booking.fare,
            tax: Math.round(totalAmount * 0.05)
          },
          seats,
          passengers
        }
      });
    } catch (error) {
      console.error("Error during booking:", error);
      alert("An error occurred while saving details.");
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="min-h-screen bg-slate-50 font-inter fade-in-up">
      <header className="flex items-center justify-between border-b px-10 py-3">
        <div className="flex gap-3 text-xl font-bold text-[#0c151d]">
          <span className="text-blue-600">FastX</span>
          <span>Passenger Details</span>
        </div>
        <div className="flex gap-4">
          <button onClick={() => navigate("/")} className="hover:underline">Home</button>
          <button onClick={() => navigate("/UserDashboard")} className="hover:underline">Profile</button>
        </div>
      </header>

      <main className="px-10 py-6 max-w-4xl mx-auto">
        <h2 className="header-title-animated mb-6">Enter Passenger Details</h2>

        {passengers.map((passenger, idx) => (
          <div key={idx} className="passenger-card p-5 mb-8 fade-up">
            <p className="text-[#4574a1] text-sm mb-1">Seat {seats[idx]}</p>
            <p className="text-[#0c151d] font-bold mb-2">Passenger {idx + 1}</p>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <input
                type="text"
                placeholder="Full Name"
                className="form-input h-12 px-4 border border-[#cddcea] focus:outline-none"
                value={passenger.fullName}
                onChange={(e) => handleChange(idx, "fullName", e.target.value)}
              />
              <input
                type="number"
                placeholder="Age"
                className="form-input h-12 px-4 border border-[#cddcea] focus:outline-none"
                value={passenger.age}
                onChange={(e) => handleChange(idx, "age", e.target.value)}
              />
              <select
                className="form-input h-12 px-4 border border-[#cddcea] focus:outline-none"
                value={passenger.gender}
                onChange={(e) => handleChange(idx, "gender", e.target.value)}
              >
                <option value="">Select Gender</option>
                <option value="Male">Male</option>
                <option value="Female">Female</option>
                <option value="Other">Other</option>
              </select>
              <input
                type="text"
                placeholder="Phone Number"
                className="form-input h-12 px-4 border border-[#cddcea] focus:outline-none"
                value={passenger.phoneNumber}
                onChange={(e) => handleChange(idx, "phoneNumber", e.target.value)}
              />
              <input
                type="email"
                placeholder="Email"
                className="form-input h-12 px-4 border border-[#cddcea] focus:outline-none"
                value={passenger.email}
                onChange={(e) => handleChange(idx, "email", e.target.value)}
              />
            </div>
          </div>
        ))}

        <div className="text-right">
          <button
            onClick={proceedToPayment}
            disabled={loading}
            className="bg-blue-600 hover:bg-blue-700 text-white rounded-full px-6 py-3 font-bold"
          >
            {loading ? "Processing..." : "Proceed to Payment"}
          </button>
        </div>
      </main>
    </div>
  );
};

export default PassengerDetails;
