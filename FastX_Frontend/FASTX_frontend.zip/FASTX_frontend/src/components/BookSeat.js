import React, { useState } from "react";
import { useNavigate, useLocation } from "react-router-dom";
import "../styles/BookSeat.css";

const generateSeats = () => {
  const seats = [];
  for (let i = 1; i <= 36; i++) {
    const number = `S${i}`;
    const status = i % 7 === 0 ? "booked" : "available";
    seats.push({ seatNumber: number, status });
  }
  return seats;
};

const BookSeat = () => {
  const [seats] = useState(generateSeats());
  const [selectedSeats, setSelectedSeats] = useState([]);
  const navigate = useNavigate();
  const location = useLocation();

  const booking = location.state?.booking || JSON.parse(localStorage.getItem("booking"));

  const toggleSeat = (seatNumber, status) => {
    if (status === "booked") {
      alert("This seat is already booked");
      return;
    }
    setSelectedSeats((prev) =>
      prev.includes(seatNumber)
        ? prev.filter((s) => s !== seatNumber)
        : [...prev, seatNumber]
    );
  };

  const proceed = () => {
   const token = localStorage.getItem('token');

  if (!token) {
    alert("Login now to book tickets.");
    navigate('/Login');
    return;
  }

  if (selectedSeats.length === 0) {
    alert("Please select at least one seat.");
    return;
    }

    if (!booking || !booking.busId || !booking.route?.origin || !booking.route?.destination || !booking.fare) {
      alert("Missing booking information. Please go back and select a bus again.");
      navigate("/searchbus");
      return;
    }

    localStorage.setItem("booking", JSON.stringify(booking));
    localStorage.setItem("seats", JSON.stringify(selectedSeats));
    const enrichedBooking = {
  ...booking,
  travelDate: booking.travelDate,
  busId: booking.busId,
  route: booking.route,
  fare: booking.fare,
  departureTime: booking.departureTime,
  busName: booking.busName,
  busType: booking.busType
};

    navigate("/PassengerDetails", {
      state: {
         booking: enrichedBooking,
    seats: selectedSeats,
      },
    });
  };

  const renderBusLayout = () => {
    const rows = [];
    for (let i = 0; i < 36; i += 4) {
      const row = seats.slice(i, i + 4);
      rows.push(row);
    }
    return rows;
  };

  return (
    <div className="bookseat-wrapper min-h-screen bg-slate-50 font-inter animate-fadeInUp">
      <header className="flex items-center justify-between border-b px-10 py-3">
        <div className="flex gap-3 text-xl font-bold text-[#0c151d]">
          <span className="text-blue-600">FastX</span>
          <span>Seat Booking</span>
        </div>
        <div className="flex gap-4">
          <button onClick={() => navigate("/")} className="hover:underline">Home</button>
          <button onClick={() => navigate("/AboutUs")} className="hover:underline">About</button>
          <button onClick={() => navigate("/Contact")} className="hover:underline">Contact</button>
                    <button onClick={() => navigate("/UserDashboard")} className="hover:underline">Profile</button>

        </div>
      </header>

      <main className="flex flex-col items-center justify-center py-8 px-4">
        <div className="bg-white p-6 rounded-xl shadow-xl w-full max-w-4xl animate-fadeInUp">
          <h1 className="text-2xl font-bold mb-6 text-center text-[#0c151d]">Select Your Seats</h1>

          <div className="flex justify-center mb-6">
            <div className="bg-gray-200 px-4 py-2 rounded shadow text-sm flex gap-6">
              <span><span className="inline-block w-4 h-4 bg-cyan-500 rounded-sm mr-2"></span>Selected</span>
              <span><span className="inline-block w-4 h-4 bg-gray-300 rounded-sm mr-2"></span>Available</span>
              <span><span className="inline-block w-4 h-4 bg-red-500 rounded-sm mr-2"></span>Booked</span>
            </div>
          </div>

          <div className="flex flex-col items-center mb-6">
            <div className="bus-container bg-gray-100 p-6 rounded-lg relative">
              {renderBusLayout().map((row, idx) => (
                <div key={idx} className="flex justify-center gap-8 mb-2">
                  <div className="flex gap-3">
                    {row.slice(0, 2).map((seat) => (
                      <div
                        key={seat.seatNumber}
                        onClick={() => toggleSeat(seat.seatNumber, seat.status)}
                        className={`w-10 h-10 rounded-md flex items-center justify-center font-semibold text-sm
                          ${seat.status === "booked"
                            ? "bg-red-500 text-white cursor-not-allowed"
                            : selectedSeats.includes(seat.seatNumber)
                            ? "bg-cyan-500 text-white"
                            : "bg-gray-300 hover:bg-cyan-300 cursor-pointer"}
                          transition`}
                      >
                        {seat.seatNumber}
                      </div>
                    ))}
                  </div>
                  <div className="flex gap-3">
                    {row.slice(2, 4).map((seat) => (
                      <div
                        key={seat.seatNumber}
                        onClick={() => toggleSeat(seat.seatNumber, seat.status)}
                        className={`w-10 h-10 rounded-md flex items-center justify-center font-semibold text-sm
                          ${seat.status === "booked"
                            ? "bg-red-500 text-white cursor-not-allowed"
                            : selectedSeats.includes(seat.seatNumber)
                            ? "bg-cyan-500 text-white"
                            : "bg-gray-300 hover:bg-cyan-300 cursor-pointer"}
                          transition`}
                      >
                        {seat.seatNumber}
                      </div>
                    ))}
                  </div>
                </div>
              ))}
            </div>
          </div>

          <div className="flex justify-between items-center">
            <p className="text-sm font-medium text-gray-700">
              Selected Seats: {" "}
              <span className="text-blue-600 font-bold">
                {selectedSeats.join(", ") || "None"}
              </span>
            </p>
            <button
              onClick={proceed}
              className="rounded-full bg-blue-600 text-white px-6 py-2 font-semibold hover:bg-blue-700 transition"
            >
              Continue
            </button>
          </div>
        </div>
      </main>
    </div>
  );
};

export default BookSeat;
