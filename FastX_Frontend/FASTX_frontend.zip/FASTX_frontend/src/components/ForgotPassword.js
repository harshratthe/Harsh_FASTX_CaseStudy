import React, { useState } from 'react';
import '../styles/forgotPassword.css';
import axios from 'axios';

const ForgotPassword = () => {
  const [email, setEmail] = useState('');
  const [status, setStatus] = useState('');

  const handleForgotPassword = async () => {
    try {
      const res = await axios.post('http://localhost:8080/users/forgot-password', null, {
        params: { email },
      });
      setStatus(res.data);
    } catch (err) {
      setStatus('Failed to send reset email. Please try again.');
    }
  };

  return (
    <div className="forgot-wrapper">
      <header className="forgot-header">
        <div className="brand">
          <svg viewBox="0 0 48 48" fill="none" xmlns="http://www.w3.org/2000/svg" className="logo-icon">
            <path d="M44 4H30.6666V17.3334H17.3334V30.6666H4V44H44V4Z" fill="currentColor" />
          </svg>
          <h2 className="brand-title">FastX</h2>
        </div>
      </header>

      <div className="forgot-container">
        <h2 className="forgot-title">Forgot Password</h2>
        <p className="forgot-subtext">Enter your registered email to receive password reset instructions.</p>

        <input
          type="text"
          placeholder="Email"
          className="form-input"
          value={email}
          onChange={(e) => setEmail(e.target.value)}
        />

        <button className="forgot-button" onClick={handleForgotPassword}>
          Send Reset Link
        </button>

        {status && <p className="forgot-status">{status}</p>}
      </div>
    </div>
  );
};

export default ForgotPassword;
