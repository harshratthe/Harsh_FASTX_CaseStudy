import React, { useState } from 'react';
import '../styles/Contact.css';
import { useNavigate } from 'react-router-dom';

const Contact = () => {
  const navigate = useNavigate();
  const [showSuccess, setShowSuccess] = useState(false);

  const [form, setForm] = useState({
    name: '',
    email: '',
    phone: '',
    subject: '',
    message: '',
  });

  const handleChange = (e) => {
    const { name, value } = e.target;
    setForm((prev) => ({ ...prev, [name]: value }));
  };

  const isFormValid = () =>
    form.name.trim() &&
    form.email.trim() &&
    form.subject.trim() &&
    form.message.trim();

  const handleSubmit = (e) => {
    e.preventDefault();
    if (!isFormValid()) return;
    setShowSuccess(true);
    setTimeout(() => setShowSuccess(false), 3000);
    setForm({ name: '', email: '', phone: '', subject: '', message: '' });
  };

  return (
    <div className="contact-page relative flex min-h-screen flex-col bg-slate-50 font-jakarta">
      <header className="flex items-center justify-between border-b border-[#e6edf4] px-10 py-3">
        <div className="flex items-center gap-4 text-[#0c151d]">
          <div className="w-4 h-4">
            <svg viewBox="0 0 48 48" fill="none" xmlns="http://www.w3.org/2000/svg">
              <path d="M44 4H30.6666V17.3334H17.3334V30.6666H4V44H44V4Z" fill="currentColor" />
            </svg>
          </div>
          <h2 className="text-lg font-bold tracking-tight">FastX</h2>
        </div>
        <div className="flex items-center gap-8">
          <a className="text-sm font-medium" href="/">Home</a>
          <button onClick={() => navigate('/signin')} className="h-10 px-4 rounded-full bg-[#e6edf4] text-sm font-bold">
            Login
          </button>
          <div
            className="w-10 h-10 bg-cover bg-center rounded-full"
            style={{ backgroundImage: `url('https://lh3.googleusercontent.com/aida-public/AB6AXu...')` }}
          ></div>
        </div>
      </header>

      <main className="px-4 sm:px-40 py-5 flex justify-center">
        <div className="max-w-3xl w-full">
          <div className="p-4">
            <h1 className="text-2xl font-bold text-[#0c151d]">We're here to help!</h1>
            <p className="text-sm text-[#4574a1]">Have questions about your booking, refund, or journey? Reach out below or explore our FAQs.</p>
          </div>

          <h2 className="text-xl font-bold text-[#0c151d] px-4 pt-5 pb-3">Frequently Asked Questions</h2>
          <div className="flex flex-col gap-3 p-4">
            {[
              "How do I cancel my ticket?",
              "What is the refund policy?",
              "I didn't receive my ticket email or SMS. What should I do?",
              "Can I reschedule my booking?"
            ].map((q, i) => (
              <details key={i} className="rounded-xl border border-[#cddcea] bg-slate-50 p-4 group">
                <summary className="flex justify-between cursor-pointer">
                  <span className="text-sm font-medium text-[#0c151d]">{q}</span>
                  <svg className="w-5 h-5 text-[#0c151d] group-open:rotate-180 transition-transform" fill="currentColor" viewBox="0 0 256 256">
                    <path d="M213.66,101.66l-80,80a8,8,0,0,1-11.32,0l-80-80A8,8,0,0,1,53.66,90.34L128,164.69l74.34-74.35a8,8,0,0,1,11.32,11.32Z" />
                  </svg>
                </summary>
                <p className="text-sm text-[#4574a1] pt-2">You can cancel from the ticket details page before the departure time.</p>
              </details>
            ))}
          </div>

          <h2 className="text-xl font-bold text-[#0c151d] px-4 pt-5 pb-3">Contact Us</h2>
          <form className="space-y-4 px-4" onSubmit={handleSubmit}>
            <div className="flex flex-col">
              <label className="text-base font-medium text-[#0c151d] pb-2">Name</label>
              <input name="name" value={form.name} onChange={handleChange} type="text" placeholder="Enter your name" className="contact-input" />
            </div>
            <div className="flex flex-col">
              <label className="text-base font-medium text-[#0c151d] pb-2">Email</label>
              <input name="email" value={form.email} onChange={handleChange} type="email" placeholder="Enter your email" className="contact-input" />
            </div>
            <div className="flex flex-col">
              <label className="text-base font-medium text-[#0c151d] pb-2">Phone Number (optional)</label>
              <input name="phone" value={form.phone} onChange={handleChange} type="text" placeholder="Enter your phone number" className="contact-input" />
            </div>
            <div className="flex flex-col">
              <label className="text-base font-medium text-[#0c151d] pb-2">Subject</label>
              <select name="subject" value={form.subject} onChange={handleChange} className="contact-input">
                <option value="">Select a subject</option>
                <option>Ticket Cancellation</option>
                <option>Refund Not Received</option>
                <option>Payment Failure</option>
                <option>Seat Selection Issue</option>
                <option>Bus Not Arrived</option>
                <option>Others</option>
              </select>
            </div>
            <div className="flex flex-col">
              <label className="text-base font-medium text-[#0c151d] pb-2">Message</label>
              <textarea name="message" value={form.message} onChange={handleChange} placeholder="Enter your message" className="contact-input min-h-[144px]" />
            </div>
            <div className="flex justify-end">
              <button type="submit" className="contact-button" disabled={!isFormValid()}>
                Submit
              </button>
            </div>

            {showSuccess && (
              <div className="submit-success-card">Submitted Successfully</div>
            )}
          </form>

          <div className="pt-5 px-4">
            <h2 className="text-xl font-bold text-[#0c151d] pb-3">Alternative Contact Info</h2>
            <p className="alt-contact-info">📞 Customer Support: +91-7890123456</p>
            <p className="alt-contact-info">📧 Email: support@fastx.in</p>
            <p className="alt-contact-info">🕒 Support Timing: 8 AM to 10 PM IST</p>
          </div>
        </div>
      </main>

      <footer className="flex justify-center py-10">
        <div className="text-center space-y-4 text-[#4574a1] text-base">
          <div className="flex flex-wrap justify-center gap-6">
            <a href="#">About Us</a>
            <a href="#">Privacy Policy</a>
            <a href="#">Terms of Use</a>
          </div>
          <p>© 2025 FastX. All rights reserved.</p>
        </div>
      </footer>
    </div>
  );
};

export default Contact;
