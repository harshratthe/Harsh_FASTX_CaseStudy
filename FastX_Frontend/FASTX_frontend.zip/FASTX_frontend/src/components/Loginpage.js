import React, { useState } from 'react';
import '../styles/login.css';
import axios from 'axios';
import { useNavigate } from 'react-router-dom';

const Login = () => {
  const [role, setRole] = useState('PASSENGER'); 
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [showModal, setShowModal] = useState(false);
  const [forgotEmail, setForgotEmail] = useState('');
  const [loading, setLoading] = useState(false); 
const navigate = useNavigate();

  const handleLogin = async () => {
    if (!email.trim() || !password.trim()) {
      return alert('Please enter both email and password.');
    }

    const endpoint =
      role === 'ADMIN'
        ? '/users/login/admin'
        : role === 'OPERATOR'
        ? '/users/login/operator'
        : '/users/login';

    setLoading(true);
    try {
      const res = await axios.post(`http://localhost:7000${endpoint}`, {
  email: email.trim(),
  password,
});

const token = res.data.token; 
if (!token) throw new Error('No token received');

localStorage.setItem('token', token);
localStorage.setItem('role', role);
localStorage.setItem('userEmail', email.trim());
localStorage.setItem('user', JSON.stringify(res.data.user)); 
localStorage.setItem('userId', res.data.user.id); // or user.userId if your field name is that



if (role === 'ADMIN') navigate('/AdminDashboard');
else if (role === 'OPERATOR') navigate('/BusOperatorDashboard');
else navigate('/');

   } catch (err) {
  console.log("🔴 FULL ERROR OBJECT:", err);
  console.log("🔴 RESPONSE:", err.response);
  console.log("🔴 RESPONSE DATA:", err.response?.data);
  console.log("🔴 STATUS:", err.response?.status);

  const data = err.response?.data;
  const message = typeof data === 'string'
    ? data  
    : data?.message || 'Login failed. Please check your credentials.';

  alert(message);
} finally {
      setLoading(false);
    }
  };

  const handleForgotPassword = async () => {
    if (!forgotEmail.trim()) return alert('Enter your email');

    try {
      const res = await axios.post('http://localhost:7000/users/forgot-password', null, {
        params: { email: forgotEmail.trim() },
      });
      alert(res.data || 'Reset link sent');
      setShowModal(false);
      setForgotEmail('');
    } catch (err) {
      alert(err.response?.data || 'Error sending reset link');
    }
  };

  return (
    <div className="login-wrapper">
      <header className="login-header">
        <div className="brand">
          <svg viewBox="0 0 48 48" fill="none" xmlns="http://www.w3.org/2000/svg" className="logo-icon">
            <path d="M44 4H30.6666V17.3334H17.3334V30.6666H4V44H44V4Z" fill="currentColor" />
          </svg>
          <h2 className="brand-title">FastX</h2>
        </div>
      </header>

      <div className="login-container">
        <h2 className="login-title">Welcome to FastX</h2>

        <div className="role-toggle">
          {['PASSENGER', 'OPERATOR', 'ADMIN'].map((r) => (
            <label key={r} className={`role-option ${role === r ? 'active' : ''}`}>
              <span>{r.charAt(0) + r.slice(1).toLowerCase()}</span>
              <input
                type="radio"
                name="role"
                value={r}
                className="hidden"
                checked={role === r}
                onChange={() => setRole(r)}
              />
            </label>
          ))}
        </div>

        <input
          type="email"
          placeholder="Email"
          className="form-input"
          value={email}
          onChange={(e) => setEmail(e.target.value)}
        />

        <input
          type="password"
          placeholder="Password"
          className="form-input"
          value={password}
          onChange={(e) => setPassword(e.target.value)}
        />

        <button className="login-button" onClick={handleLogin} disabled={loading}>
          {loading ? 'Logging in...' : 'Login'}
        </button>

        <p className="extra-link" onClick={() => setShowModal(true)}>
          Forgot Password?
        </p>

        <p className="extra-link">
          Don’t have an account?
          <span className="register-link" onClick={() => navigate('/SignUp')}>
            &nbsp;Register here
          </span>
        </p>
      </div>

      {showModal && (
        <div className="modal-overlay" onClick={() => setShowModal(false)}>
          <div className="modal-card" onClick={(e) => e.stopPropagation()}>
            <h2 className="modal-title">Forgot Password</h2>
            <input
              type="email"
              placeholder="Enter your email"
              className="form-input"
              value={forgotEmail}
              onChange={(e) => setForgotEmail(e.target.value)}
            />
            <button className="login-button mt-4" onClick={handleForgotPassword}>
              Send Reset Link
            </button>
          </div>
        </div>
      )}
    </div>
  );
};

export default Login;
