import React, { useState } from 'react';
import '../styles/signup.css';
import axios from 'axios';
import { useNavigate } from 'react-router-dom';
import logo from '../assets/FastX Logo Bgremoved.png';

const SignUp = () => {
  const navigate = useNavigate();
  const [formData, setFormData] = useState({
    userName: '',
    email: '',
    phone: '',
    address: '',
    password: '',
  });

  const handleChange = (e) => {                       //      const handleNameChange = (e) =>  {
    setFormData((prev) => ({                          //      setFormData(prev => ({ ...prev, userName: e.target.value }));
      ...prev,                                        //                                    };
      [e.target.name]: e.target.value,                //       const handleEmailChange = (e) => {
    }));                                              //          setFormData(prev => ({ ...prev, email: e.target.value }));
  };                                                 //                                 };

  const handleSubmit = async () => {
    try {
      await axios.post('http://localhost:7000/users/register', {
        ...formData,
        role: 'PASSENGER',
      });
      alert('Account created successfully!');
      navigate('/login');
    } catch (err) {
      alert('Signup failed: ' + (err.response?.data || 'Unknown error'));
    }
  };

  return (
    <div className="signup-wrapper animate-fadeIn">
      <header className="signup-header">
        <div className="brand">
          <img src={logo} alt="FastX Logo" className="logo-image" />
          <h2 className="brand-title">FastX</h2>
        </div>
      </header>

      <div className="signup-container">
        <h2 className="signup-title">Sign Up to Book Your Journey</h2>

        {['userName', 'email', 'phone', 'address', 'password'].map((field) => (
          <input
            key={field}
            type={field === 'password' ? 'password' : 'text'}
            name={field}
            placeholder={
              {
                userName: 'Full Name',
                email: 'Email Address',
                phone: 'Phone Number',
                address: 'Address',
                password: 'Password',
              }[field]
            }
            className="form-input"
            value={formData[field]}
            onChange={handleChange}
          />
        ))}

        <label className="checkbox-container">
          <input type="checkbox" className="checkbox-input" />
          <span>I agree to the Terms & Conditions</span>
        </label>

        <button className="signup-button" onClick={handleSubmit}>
          Create Account
        </button>

        <p className="extra-link">
          Already have an account?{' '}
          <span className="register-link" onClick={() => navigate('/')}>
            Login
          </span>
        </p>
      </div>
    </div>
  );
};

export default SignUp;
