import React, { useEffect, useState } from 'react';
import '../styles/SearchBus.css';
import axios from 'axios';
import { useNavigate, useLocation } from 'react-router-dom';
import BusBanner from '../assets/image.png';

const amenitiesList = [
  'WIFI', 'AC', 'NON_AC', 'CHARGING_PORT', 'WATER_BOTTLE',
  'BLANKET', 'RECLINER_SEAT', 'TV', 'SNACKS'
];

const SearchBus = () => {
  const [buses, setBuses] = useState([]);
  const [filteredBuses, setFilteredBuses] = useState([]);
  const [loading, setLoading] = useState(true);
  const [selectedAmenities, setSelectedAmenities] = useState([]);
  const [sortOption, setSortOption] = useState('');

  const navigate = useNavigate();
  const location = useLocation();

  const queryParams = new URLSearchParams(location.search);
  const from = queryParams.get('from');
  const to = queryParams.get('to');
  const date = queryParams.get('date');

  useEffect(() => {
    if (!from || !to || !date) {
      setLoading(false);
      return;
    }

    setLoading(true);
    axios
      .get('http://localhost:7000/buses/search', {
        params: { origin: from, destination: to, date },
        headers: { Authorization: localStorage.getItem('token') || '' },
      })
      .then((res) => {
        setBuses(res.data);
        setFilteredBuses(res.data);
        setLoading(false);
      })
      .catch(() => {
        setBuses([]);
        setFilteredBuses([]);
        setLoading(false);
      });
  }, [from, to, date]);

  useEffect(() => {
    let filtered = [...buses];
    if (selectedAmenities.length > 0) {
      filtered = filtered.filter((bus) =>
        selectedAmenities.every((a) => bus.amenities.includes(a))
      );
    }
    if (sortOption === 'fare') filtered.sort((a, b) => a.pricePerSeat - b.pricePerSeat);
    else if (sortOption === 'departure') filtered.sort((a, b) => a.departure.localeCompare(b.departure));
    else if (sortOption === 'arrival') filtered.sort((a, b) => a.arrival.localeCompare(b.arrival));

    setFilteredBuses(filtered);
  }, [selectedAmenities, sortOption, buses]);

  const toggleAmenity = (amenity) => {
    setSelectedAmenities((prev) =>
      prev.includes(amenity) ? prev.filter((a) => a !== amenity) : [...prev, amenity]
    );
  };
  const handleBookSeat = (bus) => {
  const bookingPayload = {
    busId: bus.busId,
    busName: bus.busName,
    route: {
      routeId: bus.route?.routeId,
      origin: from,
      destination: to
    },
    departureTime: bus.departure,
    arrivalTime: bus.arrival,
    travelDate: date,
    fare: bus.pricePerSeat,
    busType: bus.busType
  };

  console.log("Booking payload →", bookingPayload); // ✅ LOG HERE

  navigate(`/BookSeat/${bus.busId}`, {
    state: { booking: bookingPayload }
  });
};


  return (
    <div className="searchbus-wrapper min-h-screen w-full bg-[#f8f9fc] font-['Plus Jakarta Sans','Noto Sans','sans-serif']">
      <header className="flex justify-between items-center border-b border-[#e6e9f4] px-10 py-4">
        <div onClick={() => navigate('/')} className="flex items-center gap-2 cursor-pointer text-[#0d0f1c]">
          <svg viewBox="0 0 48 48" fill="none" className="w-5 h-5">
            <path d="M44 4H30.6666V17.3334H17.3334V30.6666H4V44H44V4Z" fill="currentColor" />
          </svg>
          <h1 className="text-lg font-bold">FastX</h1>
        </div>
        <div className="flex items-center gap-8">
          {['Home', 'About', 'Contact'].map((label) => (
            <span key={label} onClick={() => navigate(`/${label === 'Home' ? '' : label}`)}
              className="text-sm text-[#0d0f1c] font-medium cursor-pointer hover:text-[#2a6cb9]">
              {label}
            </span>
          ))}
           
        {localStorage.getItem('token') ? (
  <button
    onClick={() => navigate('/UserDashboard')}
    className="bg-[#e6edf4] hover:bg-[#d4e3f4] px-4 py-2 rounded-full font-bold text-sm text-[#0c151d] transition-transform hover:scale-105"
  >
    Your Profile
  </button>
) : (
  <button
    onClick={() => navigate('/login')}
    className="bg-[#e6edf4] hover:bg-[#d4e3f4] px-4 py-2 rounded-full font-bold text-sm text-[#0c151d] transition-transform hover:scale-105"
  >
    Login / Sign Up
  </button>
)}




        </div>
      </header>

      <div className="filter-section px-10 py-4 flex flex-wrap items-center gap-4 bg-white border-b border-[#e6e9f4]">
        <span className="text-sm font-semibold text-[#0d0f1c]">Filters:</span>
        {amenitiesList.map((amenity) => (
          <label key={amenity} className="text-sm text-[#0d0f1c] flex items-center gap-1 font-medium">
            <input type="checkbox" checked={selectedAmenities.includes(amenity)} onChange={() => toggleAmenity(amenity)} />
            {amenity.replaceAll('_', ' ')}
          </label>
        ))}
        <div className="ml-auto flex items-center gap-2 text-sm font-medium text-[#0d0f1c]">
          Sort by:
          <select
            value={sortOption}
            onChange={(e) => setSortOption(e.target.value)}
            className="px-2 py-1 border border-gray-300 rounded-md text-[#0d0f1c]"
          >
            <option value="">None</option>
            <option value="fare">Fare (Low to High)</option>
            <option value="departure">Departure Time</option>
            <option value="arrival">Arrival Time</option>
          </select>
        </div>
      </div>

      <div className="px-10 py-3 text-sm text-[#47569e]">
        Showing buses from <strong>{from}</strong> to <strong>{to}</strong> on <strong>{date}</strong>
      </div>

      <div className="px-10 py-4">
        {loading ? (
          <p className="text-[#47569e]">Loading buses...</p>
        ) : filteredBuses.length === 0 ? (
          <p className="text-red-600">No buses found for selected filters.</p>
        ) : (
          filteredBuses.map((bus) => (
            <div key={bus.busId} className="bus-card mb-6 rounded-xl border border-[#d1d5db] bg-white p-4 shadow-sm hover:shadow-lg transition-transform hover:-translate-y-1">
              <div className="flex justify-between items-center gap-6">
                <div className="flex flex-col gap-1">
                  <h3 className="text-lg font-bold text-[#0d0f1c]">{bus.busName}</h3>
                  <p className="text-sm text-[#47569e]">{bus.departure} → {bus.arrival} | Seats: {bus.totalSeats}</p>
                  <p className="text-sm text-[#47569e]">Fare: ₹{bus.pricePerSeat}</p>
                  <p className="text-sm text-[#47569e]">Bus Type: {bus.busType.replaceAll('_', ' ')}</p>
                  <div className="flex flex-wrap gap-2 mt-2 text-xs">
                    {bus.amenities?.map((a, i) => (
                      <span key={i} className="amenity-badge">{a.replaceAll('_', ' ')}</span>
                    ))}
                  </div>
                </div>
                <div className="flex flex-col items-end gap-2">
                  <img src={BusBanner} alt="bus" className="w-full h-48 object-cover rounded-xl mb-4" />
                  <button
  onClick={() => handleBookSeat(bus)}
  className="bg-[#3182cd] hover:bg-[#2563eb] text-white font-bold px-4 py-2 rounded-full text-sm transition"
>
  Book Now
</button>

                </div>
              </div>
            </div>
          ))
        )}
      </div>
    </div>
  );
};

export default SearchBus;
