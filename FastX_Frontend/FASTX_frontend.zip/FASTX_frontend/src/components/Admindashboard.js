import React, { useEffect, useState } from "react";
import axios from "axios";
import { useNavigate } from "react-router-dom";
import { motion } from "framer-motion";
import "../styles/AdminDashboard.css";

const AdminDashboard = () => {
  const [users, setUsers] = useState([]);
  const [operators, setOperators] = useState([]);
  const [routes, setRoutes] = useState([]);
  const [editRouteId, setEditRouteId] = useState(null);
  const [showAddRouteForm, setShowAddRouteForm] = useState(false);

  const [newRoute, setNewRoute] = useState({
    origin: "",
    destination: "",
    departureTime: "",
    arrivalTime: "",
    distance: "",
    fare: ""
  });

  const token = localStorage.getItem("token");
  const email = localStorage.getItem("email");
  const navigate = useNavigate();

  useEffect(() => {
    if (!token) navigate("/login");
    const headers = { headers: { Authorization: `Bearer ${token}` } };

    axios.get("http://localhost:7000/users/all", headers).then((res) => setUsers(res.data));
    axios.get("http://localhost:7000/users/operators", headers).then((res) => setOperators(res.data));
    axios.get("http://localhost:7000/routes/all", headers).then((res) => setRoutes(res.data));
  }, []);

 const handleDeleteUser = async (id) => {
  if (!window.confirm("Are you sure you want to delete this user?")) return;

  try {
    await axios.delete(`http://localhost:7000/users/delete/${id}`, {
      headers: { Authorization: `Bearer ${token}` }
    });
    alert("User deleted successfully.");
    // Optionally update state here instead of full reload
    setUsers(prev => prev.filter(user => user.id !== id));
  } catch (error) {
    if (error.response && error.response.status === 409) {
      alert("Cannot delete: User has active bookings.");
    } else {
      alert("Deletion failed. Please try again.");
    }
  }
};


  const handleDeleteOperator = async (id) => {
  if (!window.confirm("Delete this operator?")) return;

  try {
    const response = await axios.delete(`http://localhost:7000/users/operators/${id}`, {
      headers: { Authorization: `Bearer ${token}` }
    });
    console.log("Deleted:", response.data);
    window.location.reload();
  } catch (err) {
    console.error("DELETE ERROR", err.response?.status, err.response?.data);
    alert("Deletion failed: " + (err.response?.data?.message || "Unauthorized"));
  }
};



  const handleRouteChange = (e) => {
    setNewRoute({ ...newRoute, [e.target.name]: e.target.value });
  };

  const handleAddOrUpdateRoute = () => {
    const headers = {
      headers: { Authorization: `Bearer ${token}`, "Content-Type": "application/json" }
    };
    const endpoint = editRouteId
      ? `http://localhost:7000/routes/update/${editRouteId}`
      : "http://localhost:7000/routes/create";
    const method = editRouteId ? axios.put : axios.post;

    method(endpoint, newRoute, headers).then(() => {
      setShowAddRouteForm(false);
      setEditRouteId(null);
      window.location.reload();
    });
  };

  const handleEditRoute = (route) => {
    setNewRoute(route);
    setEditRouteId(route.routeId);
    setShowAddRouteForm(true);
  };

  const handleDeleteRoute = (id) => {
    if (!window.confirm("Delete this route?")) return;
    axios.delete(`http://localhost:7000/routes/delete/${id}`, {
      headers: { Authorization: `Bearer ${token}` }
    }).then(() => window.location.reload());
  };

  return (
    <motion.div className="operator-dashboard" initial={{ opacity: 0, y: -20 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.5 }}>
      <header className="operator-header">
        <div className="logo-section" onClick={() => navigate("/")}> <h2 className="title">FastX Admin</h2> </div>
        <div className="flex gap-3">
          
          <motion.button whileHover={{ scale: 1.05 }} whileTap={{ scale: 0.95 }} className="logout-btn" onClick={() => { localStorage.clear(); navigate("/login"); }}>Logout</motion.button>
        </div>
      </header>

      <main className="px-10 py-6">
        <motion.h2 className="text-2xl font-bold mb-6" initial={{ opacity: 0 }} animate={{ opacity: 1 }} transition={{ delay: 0.3 }}>Welcome Admin {email}</motion.h2>

        {/* Users */}
        <h3 className="section-heading">Manage Users</h3>
        <motion.div className="table-container" initial={{ opacity: 0 }} animate={{ opacity: 1 }} transition={{ delay: 0.4 }}>
          <table className="data-table">
            <thead><tr><th>Name</th><th>Email</th><th>Phone</th><th>Role</th><th>Action</th></tr></thead>
            <tbody>
              {users.map(user => (
                <motion.tr key={user.userId} whileHover={{ scale: 1.01 }}>
                  <td>{user.userName}</td>
                  <td>{user.email}</td>
                  <td>{user.phone}</td>
                  <td>{user.role}</td>
                  <td><motion.button whileTap={{ scale: 0.9 }} className="delete-btn" onClick={() => handleDeleteUser(user.userId)}>🗑️</motion.button></td>
                </motion.tr>
              ))}
            </tbody>
          </table>
        </motion.div>

        {/* Operators */}
        <h3 className="section-heading mt-10">Manage Bus Operators</h3>
        <motion.div className="table-container" initial={{ opacity: 0 }} animate={{ opacity: 1 }} transition={{ delay: 0.5 }}>
          <table className="data-table">
            <thead><tr><th>Name</th><th>Email</th><th>Phone</th><th>Action</th></tr></thead>
            <tbody>
              {operators.map(op => (
                <motion.tr key={op.userId} whileHover={{ scale: 1.01 }}>
                  <td>{op.userName}</td>
                  <td>{op.email}</td>
                  <td>{op.phone}</td>
                  <td><motion.button whileTap={{ scale: 0.9 }} className="delete-btn" onClick={() => handleDeleteOperator(op.userId)}>🗑️</motion.button></td>
                </motion.tr>
              ))}
            </tbody>
          </table>
        </motion.div>

        {/* Routes */}
        <div className="flex justify-between items-center mt-10 mb-4">
          <h3 className="section-heading">Manage Routes</h3>
          <motion.button whileHover={{ scale: 1.05 }} whileTap={{ scale: 0.95 }} className="primary-btn" onClick={() => {
            setNewRoute({ origin: "", destination: "", departureTime: "", arrivalTime: "", distance: "", fare: "" });
            setEditRouteId(null);
            setShowAddRouteForm(true);
          }}>Add Route</motion.button>
        </div>

        {showAddRouteForm && (
          <motion.div className="add-route-card" initial={{ opacity: 0, scale: 0.95 }} animate={{ opacity: 1, scale: 1 }} transition={{ duration: 0.3 }}>
            <input type="text" name="origin" placeholder="Origin" value={newRoute.origin} onChange={handleRouteChange} />
            <input type="text" name="destination" placeholder="Destination" value={newRoute.destination} onChange={handleRouteChange} />
            <input type="datetime-local" name="departureTime" value={newRoute.departureTime} onChange={handleRouteChange} />
            <input type="datetime-local" name="arrivalTime" value={newRoute.arrivalTime} onChange={handleRouteChange} />
            <input type="number" name="distance" placeholder="Distance" value={newRoute.distance} onChange={handleRouteChange} />
            <input type="number" name="fare" placeholder="Fare" value={newRoute.fare} onChange={handleRouteChange} />
            <div className="flex gap-3 mt-2">
              <motion.button whileHover={{ scale: 1.05 }} className="primary-btn" onClick={handleAddOrUpdateRoute}>{editRouteId ? "Update" : "Submit"}</motion.button>
              <motion.button whileHover={{ scale: 1.05 }} className="secondary-btn" onClick={() => setShowAddRouteForm(false)}>Cancel</motion.button>
            </div>
          </motion.div>
        )}

        <motion.div className="table-container mt-4" initial={{ opacity: 0 }} animate={{ opacity: 1 }} transition={{ delay: 0.6 }}>
          <table className="data-table">
            <thead><tr><th>Route</th><th>Departure</th><th>Arrival</th><th>Distance</th><th>Fare</th><th>Actions</th></tr></thead>
            <tbody>
              {routes.map(route => (
                <motion.tr key={route.routeId} whileHover={{ scale: 1.01 }}>
                  <td>{route.origin} → {route.destination}</td>
                  <td>{route.departureTime}</td>
                  <td>{route.arrivalTime}</td>
                  <td>{route.distance} km</td>
                  <td>₹{route.fare}</td>
                  <td>
                    <motion.button whileTap={{ scale: 0.9 }} onClick={() => handleEditRoute(route)} className="edit-btn">✏️</motion.button>
                    <motion.button whileTap={{ scale: 0.9 }} onClick={() => handleDeleteRoute(route.routeId)} className="delete-btn">🗑️</motion.button>
                  </td>
                </motion.tr>
              ))}
            </tbody>
          </table>
        </motion.div>
      </main>
    </motion.div>
  );
};

export default AdminDashboard;
