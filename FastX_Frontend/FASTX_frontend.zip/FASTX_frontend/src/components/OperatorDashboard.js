import React, { useEffect, useState } from "react";
import axios from "axios";
import "../styles/OperatorDashboard.css";
import { useNavigate } from "react-router-dom";
import { motion } from "framer-motion";

const OperatorDashboard = () => {
  const [routes, setRoutes] = useState([]);
  const [buses, setBuses] = useState([]);
  const [bookings, setBookings] = useState([]);
  const [showAddRouteForm, setShowAddRouteForm] = useState(false);
  const [showAddBusForm, setShowAddBusForm] = useState(false);
  const [editRouteId, setEditRouteId] = useState(null);
  const [editBusId, setEditBusId] = useState(null);
  const [userEmail, setUserEmail] = useState("");

  const operator = JSON.parse(localStorage.getItem("user"));
  const operatorId = operator?.userId;
  const token = localStorage.getItem("token");
  const navigate = useNavigate();

  const [newRoute, setNewRoute] = useState({
    origin: "",
    destination: "",
    departureTime: "",
    arrivalTime: "",
    distance: "",
    fare: ""
  });

  const [newBus, setNewBus] = useState({
    busNumber: "",
    busName: "",
    busType: "AC",
    totalSeats: "",
    amenities: [],
    busStatus: "ACTIVE",
    arrival: "",
    departure: "",
    pricePerSeat: "",
    date: "",
    route: { routeId: "" }
  });

  const busTypeOptions = [
    "NON_AC_SLEEPER",
    "NON_AC_SEATER",
    "AC_SEATER",
    "AC_SLEEPER"
  ];

  const amenityOptions = [
    "WIFI", "AC", "NON_AC", "CHARGING_PORT", "WATER_BOTTLE", 
    "BLANKET", "RECLINER_SEAT", "TV", "SNACKS"
  ];

  const busStatusOptions = ["ACTIVE", "INACTIVE"];

  useEffect(() => {
    if (!operatorId || !token) return;
console.log("operatorId", operatorId);
  console.log("token", token);
    axios.get(`http://localhost:7000/bookings/getbyoperator/${operatorId}`, {
      headers: { Authorization: `Bearer ${token}` }
    })
    .then(res => {
      console.log("Bookings response:", res.data);  // <-- ADD THIS TOO
      setBookings(res.data);
    })
    .catch(err => console.error("Error fetching operator bookings:", err));
  }, [operatorId, token]);

  useEffect(() => {
    fetchAllData();
  }, []);

  const fetchAllData = () => {
    if (!token || token === "null") {
      navigate("/login");
      return;
    }

    setUserEmail(localStorage.getItem("email"));
    const headers = { headers: { Authorization: `Bearer ${token}` } };

    axios.get("http://localhost:7000/routes/all", headers)
      .then(res => setRoutes(res.data))
      .catch(err => console.error("Error fetching routes:", err));

    axios.get("http://localhost:7000/buses/all", headers)
      .then(res => setBuses(res.data))
      .catch(err => console.error("Error fetching buses:", err));
  };

  const handleRouteChange = (e) => {
    setNewRoute({ ...newRoute, [e.target.name]: e.target.value });
  };

  const handleAddOrUpdateRoute = () => {
    if (!token || token === "null") {
      alert("Login expired.");
      navigate("/login");
      return;
    }

    const headers = {
      headers: {
        Authorization: `Bearer ${token}`,
        "Content-Type": "application/json"
      }
    };

    const endpoint = editRouteId
      ? `http://localhost:7000/routes/update/${editRouteId}`
      : "http://localhost:7000/routes/create";

    const axiosMethod = editRouteId ? axios.put : axios.post;

    axiosMethod(endpoint, newRoute, headers)
      .then(() => {
        alert(editRouteId ? "✅ Route updated!" : "✅ Route added!");
        setShowAddRouteForm(false);
        setEditRouteId(null);
        setNewRoute({
          origin: "",
          destination: "",
          departureTime: "",
          arrivalTime: "",
          distance: "",
          fare: ""
        });
        fetchAllData();
      })
      .catch((err) => {
        alert("❌ Operation failed.");
        console.error(err);
      });
  };

  const handleEditRoute = (route) => {
    setNewRoute(route);
    setEditRouteId(route.routeId);
    setShowAddRouteForm(true);
  };

  const handleDeleteRoute = (id) => {
    if (!window.confirm("Are you sure you want to delete this route?")) return;

    axios.delete(`http://localhost:7000/routes/delete/${id}`, {
      headers: { Authorization: `Bearer ${token}` }
    })
      .then(() => {
        alert("🗑️ Route deleted.");
        fetchAllData();
      })
      .catch((err) => {
        alert("❌ Failed to delete.");
        console.error(err);
      });
  };

  const handleBusChange = (e) => {
    const { name, value, type, checked } = e.target;

    if (name === "routeId") {
      setNewBus({ ...newBus, route: { routeId: value } });
    } else if (name === "amenities") {
      const updatedAmenities = checked
        ? [...newBus.amenities, value]
        : newBus.amenities.filter(item => item !== value);
      setNewBus({ ...newBus, amenities: updatedAmenities });
    } else {
      setNewBus({ ...newBus, [name]: value });
    }
  };

  const handleAddOrUpdateBus = () => {
    if (!token || token === "null") {
      alert("Login expired.");
      navigate("/login");
      return;
    }

    if (!operatorId || !newBus.route.routeId) {
      alert("Missing route or operator.");
      return;
    }

    const busPayload = {
      ...newBus,
      totalSeats: parseInt(newBus.totalSeats),
      pricePerSeat: parseFloat(newBus.pricePerSeat),
      operator: { userId: parseInt(operatorId) },
      route: { routeId: parseInt(newBus.route.routeId) }
    };

    const headers = {
      headers: {
        Authorization: `Bearer ${token}`,
        "Content-Type": "application/json"
      }
    };

    const endpoint = editBusId
      ? `http://localhost:7000/buses/update/${editBusId}`
      : "http://localhost:7000/buses/add";

    const axiosMethod = editBusId ? axios.put : axios.post;

    axiosMethod(endpoint, busPayload, headers)
      .then(() => {
        alert(editBusId ? "🚌 Bus updated!" : "🚌 Bus added!");
        setShowAddBusForm(false);
        setEditBusId(null);
        setNewBus({
          busNumber: "",
          busName: "",
          busType: "AC",
          totalSeats: "",
          amenities: [],
          busStatus: "ACTIVE",
          arrival: "",
          departure: "",
          pricePerSeat: "",
          date: "",
          route: { routeId: "" }
        });
        fetchAllData();
      })
      .catch((err) => {
        alert("❌ Failed to add/update bus.");
        console.error(err);
      });
  };

  const handleEditBus = (bus) => {
    setNewBus({
      ...bus,
      route: { routeId: bus.route?.routeId },
      operator: { userId: bus.operator?.userId }
    });
    setEditBusId(bus.busId);
    setShowAddBusForm(true);
  };

  const handleDeleteBus = (busId) => {
    if (!window.confirm("Delete this bus?")) return;

    axios.delete(`http://localhost:7000/buses/delete/${busId}`, {
      headers: { Authorization: `Bearer ${token}` }
    })
      .then(() => {
        alert("🗑️ Bus deleted.");
        fetchAllData();
      })
      .catch((err) => {
        alert("❌ Delete failed.");
        console.error(err);
      });
  };

  const handleLogout = () => {
    localStorage.clear();
    navigate("/login");
  };


  //**************************Design Part(JSX) ********************************************* */
  return (
    <div className="operator-dashboard">
      <header className="operator-header">
        <div className="logo-section" onClick={() => navigate('/')} style={{ cursor: 'pointer' }}>
          <svg className="logo-icon" viewBox="0 0 48 48" fill="currentColor">
            <path d="M44 4H30.6666V17.3334H17.3334V30.6666H4V44H44V4Z" />
          </svg>
          <h2 className="title">FastX</h2>
        </div>
       <div className="flex gap-3">
  <button className="logout-btn" onClick={() => navigate('/')}>
    Home
  </button>
  <button className="logout-btn" onClick={handleLogout}>
    Logout
  </button>
</div>



      </header>

      <motion.main
        className="px-10 py-6"
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.5 }}
      >
        <motion.h2
          className="text-2xl font-bold mb-5 text-[#0f151a]"
          initial={{ opacity: 0, x: -20 }}
          animate={{ opacity: 1, x: 0 }}
          transition={{ delay: 0.2, duration: 0.6 }}
        >
           Welcome, {userEmail || "Operator"}!
        </motion.h2>

        {/* --- ROUTES SECTION --- */}
        <div className="flex justify-between items-center mb-4">
          <h2 className="section-heading">Manage Routes</h2>
          <button className="primary-btn" onClick={() => {
            setNewRoute({ origin: '', destination: '', departureTime: '', arrivalTime: '', distance: '', fare: '' });
            setEditRouteId(null);
            setShowAddRouteForm(true);
          }}>
            {editRouteId ? "Edit Route" : "Add New Route"}
          </button>
        </div>

        {showAddRouteForm && (
          <motion.div className="add-route-card" initial={{ opacity: 0, scale: 0.8 }} animate={{ opacity: 1, scale: 1 }} transition={{ duration: 0.4 }}>
            <h3 className="text-xl font-bold mb-2">{editRouteId ? "Edit Route" : "Add Route"}</h3>
            <div className="form-group flex flex-col gap-3 mb-4">
              <input type="text" name="origin" placeholder="Origin" value={newRoute.origin} onChange={handleRouteChange} />
              <input type="text" name="destination" placeholder="Destination" value={newRoute.destination} onChange={handleRouteChange} />
              <input type="datetime-local" name="departureTime" value={newRoute.departureTime} onChange={handleRouteChange} />
              <input type="datetime-local" name="arrivalTime" value={newRoute.arrivalTime} onChange={handleRouteChange} />
              <input type="number" name="distance" placeholder="Distance (km)" value={newRoute.distance} onChange={handleRouteChange} />
              <input type="number" name="fare" placeholder="Fare (₹)" value={newRoute.fare} onChange={handleRouteChange} />
              <div className="flex gap-3 mt-2">
                <button className="primary-btn" onClick={handleAddOrUpdateRoute}>
                  {editRouteId ? "Update" : "Submit"}
                </button>
                <button className="secondary-btn" onClick={() => {
                  setShowAddRouteForm(false);
                  setEditRouteId(null);
                }}>Cancel</button>
              </div>
            </div>
          </motion.div>
        )}

        <div className="table-container">
          <table className="data-table">
            <thead>
              <tr>
                <th>Route</th>
                <th>Departure</th>
                <th>Arrival</th>
                <th>Distance</th>
                <th>Fare</th>
                <th>Actions</th>
              </tr>
            </thead>
            <tbody>
              {routes.map((route, idx) => (
                <motion.tr key={idx} initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.2, delay: idx * 0.05 }}>
                  <td>{route.origin} → {route.destination}</td>
                  <td>{route.departureTime}</td>
                  <td>{route.arrivalTime}</td>
                  <td>{route.distance} km</td>
                  <td>₹{route.fare}</td>
                  <td className="flex gap-2">
                    <button onClick={() => handleEditRoute(route)} className="edit-btn hover:scale-105">✏️ Edit</button>
                    <button onClick={() => handleDeleteRoute(route.routeId)} className="delete-btn hover:scale-105">🗑️ Delete</button>
                  </td>
                </motion.tr>
              ))}
            </tbody>
          </table>
        </div>

        {/* --- BUSES SECTION --- */}
        <div className="flex justify-between items-center mt-10 mb-4">
          <h2 className="section-heading">Manage Buses</h2>
          <button className="primary-btn" onClick={() => {
            setNewBus({
              busNumber: "",
              type: "",
              totalSeats: "",
              amenities: "",
              operatorName: "",
              date: "",
              route: { routeId: "" }
            });
            setEditBusId(null);
            setShowAddBusForm(true);
          }}>
            {editBusId ? "Edit Bus" : "Add New Bus"}
          </button>
        </div>

        {showAddBusForm && (
          <motion.div className="add-route-card" initial={{ opacity: 0, scale: 0.8 }} animate={{ opacity: 1, scale: 1 }} transition={{ duration: 0.4 }}>
            <h3 className="text-xl font-bold mb-2">{editBusId ? "Edit Bus" : "Add Bus"}</h3>
            <div className="form-group flex flex-col gap-3 mb-4">
              <input type="text" name="busNumber" placeholder="Bus Number" value={newBus.busNumber} onChange={handleBusChange} />
              <input type="text" name="busName"  placeholder="Bus Name" value={newBus.busName} onChange={handleBusChange}/>

             <select name="busType" value={newBus.busType} onChange={handleBusChange}>
                <option value="">-- Select Bus Type --</option>
                      {busTypeOptions.map((type) => (
                    <option key={type} value={type}>
                     {type.replaceAll("_", " ")}
                           </option>
                             ))}
                                  </select>

               <select name="busStatus" value={newBus.busStatus} onChange={handleBusChange}>
                <option value="">-- Select Bus Status --</option>
                   <option value="ACTIVE">ACTIVE</option>
                <option value="INACTIVE">INACTIVE</option>
                   </select>                      

              <input type="number" name="totalSeats" placeholder="Total Seats" value={newBus.totalSeats} onChange={handleBusChange} />
              <label className="text-sm font-medium text-gray-700">Amenities</label>
<div className="flex flex-wrap gap-2">
  {amenityOptions.map((amenity) => (
    <button
      key={amenity}
      type="button"
      className={`px-3 py-1 rounded-full border text-sm font-semibold ${
        newBus.amenities.includes(amenity)
          ? "bg-blue-500 text-white border-blue-500"
          : "bg-gray-100 text-gray-800 border-gray-300"
      }`}
      onClick={() => {
        const isSelected = newBus.amenities.includes(amenity);
        const updated = isSelected
          ? newBus.amenities.filter((a) => a !== amenity)
          : [...newBus.amenities, amenity];
        setNewBus({ ...newBus, amenities: updated });
      }}
    >
      {amenity}
    </button>
  ))}
</div>

{newBus.amenities.length > 0 && (
  <div className="mt-2 text-sm text-gray-600">
    Selected: {newBus.amenities.join(", ")}
  </div>
)}

              
              <input type="text" name="operatorName" placeholder="Operator Name" value={newBus.operatorName} onChange={handleBusChange} />
              <input type="date" name="date" value={newBus.date} onChange={handleBusChange} />
              <select name="routeId" value={newBus.route.routeId} onChange={handleBusChange}>
                <option value="">-- Select Route --</option>
                {routes.map((route) => (
                  <option key={route.routeId} value={route.routeId}>
                    {route.origin} → {route.destination}
                  </option>
                ))}
              </select>
              <div className="flex gap-3 mt-2">
                <button className="primary-btn" onClick={handleAddOrUpdateBus}>
                  {editBusId ? "Update" : "Submit"}
                </button>
                <input type="time" name="arrival" placeholder="Arrival Time" value={newBus.arrival} onChange={handleBusChange} />
<input type="time" name="departure" placeholder="Departure Time" value={newBus.departure} onChange={handleBusChange} />
<input type="number" name="pricePerSeat" placeholder="Price Per Seat" value={newBus.pricePerSeat} onChange={handleBusChange} />

                <button className="secondary-btn" onClick={() => {
                  setShowAddBusForm(false);
                  setEditBusId(null);
                }}>Cancel</button>
              </div>
            </div>
          </motion.div>
        )}
         

        <div className="table-container mt-6">
          <table className="data-table">
            <thead>
              <tr>
                <th>Bus Number</th>
                <th>Type</th>
                <th>Seats</th>
                <th>Amenities</th>
                <th>Date</th>
                <th>Route</th>
                <th>Actions</th>
              </tr>
            </thead>
            <tbody>
              {buses.map((bus, idx) => (
  <motion.tr key={bus.busId} initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.2, delay: idx * 0.05 }}>
    <td>{bus.busNumber}</td>
    <td>{bus.busType ? bus.busType.replaceAll("_", " ") : "-"}</td>
    <td>{bus.totalSeats}</td>
    <td>{Array.isArray(bus.amenities) ? bus.amenities.join(", ") : "-"}</td>
    <td>{bus.date}</td>
    <td>{bus.route?.origin} → {bus.route?.destination}</td>
    <td className="flex gap-2">
      <button onClick={() => handleEditBus(bus)} className="edit-btn hover:scale-105">✏️ Edit</button>
      <button onClick={() => handleDeleteBus(bus.busId)} className="delete-btn hover:scale-105">🗑️ Delete</button>
    </td>
  </motion.tr>
))}

            </tbody>
          </table>
        </div>

        {/* --- BOOKINGS SUMMARY --- */}
        <h2 className="section-heading mt-10">Manage Bookings</h2>
        <div className="stats-box">Active Bookings: {bookings.length}</div>

<div className="table-container mt-6">
  <table className="data-table">
    <thead>
      <tr>
        <th>Booking ID</th>
        <th>Date</th>
        <th>Status</th>
        <th>Total Amount</th>
        <th>User</th>
        <th>Bus</th>
        <th>Route</th>
      </tr>
    </thead>
    <tbody>
      {bookings.map((booking, idx) => (
        <motion.tr
          key={booking.bookingId}
          initial={{ opacity: 0, y: 10 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.2, delay: idx * 0.05 }}
        >
          <td>{booking.bookingId}</td>
          <td>{booking.bookingDate}</td>
          <td>{booking.bookingStatus}</td>
          <td>₹{booking.totalAmount}</td>
          <td>
            {booking.user?.userName} <br />
            📧 {booking.user?.email} <br />
            📞 {booking.user?.phone}
          </td>
          <td>
            {booking.bus?.busName} ({booking.bus?.busNumber}) <br />
            {booking.bus?.busType?.replaceAll("_", " ")} <br />
            ₹{booking.bus?.pricePerSeat} /seat
          </td>
          <td>
            {booking.route?.origin} → {booking.route?.destination} <br />
            ⏱ {booking.route?.departureTime?.split("T")[1]} - {booking.route?.arrivalTime?.split("T")[1]}
          </td>
        </motion.tr>
      ))}
    </tbody>
  </table>
</div>



      </motion.main>
    </div>
  );
};

export default OperatorDashboard;
