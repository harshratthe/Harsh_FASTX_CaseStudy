// src/components/PaymentSuccess.js
import React, { useRef } from 'react';
import { useNavigate, useLocation } from 'react-router-dom';
import { QRCodeSVG } from 'qrcode.react';
import jsPDF from 'jspdf';
import html2canvas from 'html2canvas';
import '../styles/BookingConfirmed.css';

const PaymentSuccess = () => {
  const navigate = useNavigate();
  const location = useLocation();
  const ticketRef = useRef();

  const { booking } = location.state || {};

  if (!booking) {
    return (
      <div className="flex items-center justify-center min-h-screen text-red-600 font-semibold">
        Booking details not available.
      </div>
    );
  }

  const {
    bookingId, busName, route, departureTime, travelDate,
    seatNumbers, totalAmount, passengers = []
  } = booking;

  const passengerNames = passengers.map(p => p.name).join(', ');
  const bookingInfo = `Passenger(s): ${passengerNames} | Seat(s): ${seatNumbers.join(', ')} | Bus: ${busName} | Route: ${route?.origin} to ${route?.destination} | Date: ${travelDate} ${departureTime} | Amount: ₹${totalAmount} | Booking ID: ${bookingId}`;

  // 🔽 Download Ticket as PDF
  const handleDownloadPDF = async () => {
    const element = ticketRef.current;
    const canvas = await html2canvas(element);
    const imgData = canvas.toDataURL('image/png');

    const pdf = new jsPDF();
    const imgProps = pdf.getImageProperties(imgData);
    const pdfWidth = pdf.internal.pageSize.getWidth();
    const pdfHeight = (imgProps.height * pdfWidth) / imgProps.width;

    pdf.addImage(imgData, 'PNG', 0, 0, pdfWidth, pdfHeight);
    pdf.save(`FastX-Ticket-${bookingId}.pdf`);
  };

  return (
    <div className="payment-success-container">
      <header className="payment-success-header">
        <div className="brand">
          <h2>FastX</h2>
        </div>
        <div className="nav">
          <a href="/">Home</a>
          <button onClick={() => navigate('/UserDashboard')}>My Booking History</button>
          <div className="avatar"></div>
        </div>
      </header>

      <div className="payment-success-content">
        <h1 className="animated-text">Booking Confirmed</h1>

        <div className="success-summary" ref={ticketRef}>
          <div className="image-banner"></div>

          <div className="details">
            <p><strong>Passenger(s):</strong> {passengerNames}</p>
            <p><strong>Seats:</strong> {seatNumbers.join(', ')}</p>
            <p><strong>Bus:</strong> {busName}</p>
            <p><strong>Route:</strong> {route?.origin} to {route?.destination}</p>
            <p><strong>Date:</strong> {travelDate}</p>
            <p><strong>Departure Time:</strong> {departureTime}</p>
            <p><strong>Amount Paid:</strong> ₹{totalAmount}</p>
            <p><strong>Booking ID:</strong> {bookingId}</p>
          </div>

          <div className="qr-code">
            <QRCodeSVG value={bookingInfo} size={128} />
          </div>
        </div>

        <div className="buttons">
          <button className="primary" onClick={() => navigate('/')}>
            Back to Home
          </button>
          <button onClick={() => navigate('/UserDashboard')}>
            View Bookings
          </button>
          <button onClick={handleDownloadPDF} className="primary">
            Download / Print Ticket
          </button>
        </div>

        <p className="note">
          Ticket details have also been sent to your email and SMS.
        </p>
      </div>
    </div>
  );
};

export default PaymentSuccess;
