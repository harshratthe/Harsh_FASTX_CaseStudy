import React, { useState } from 'react';
import '../styles/Payment.css';
import { useNavigate, Link, useLocation } from 'react-router-dom';
import axios from 'axios';

const Payment = () => {
  const navigate = useNavigate();
  const location = useLocation();

  let { booking, seats = [], passengers = [] } = location.state || {};
   console.log("🧾 Payment received booking:", booking);
  // Fallback from localStorage
  if (!booking || !seats.length || !passengers.length) {
    booking = JSON.parse(localStorage.getItem("booking")) || null;
    seats = JSON.parse(localStorage.getItem("seats")) || [];
    passengers = JSON.parse(localStorage.getItem("passengers")) || [];
  }

  const [loading, setLoading] = useState(false);
  const [paymentMethod, setPaymentMethod] = useState('UPI');
  const [promoCode, setPromoCode] = useState('');
  const [discount, setDiscount] = useState(0);
  const [promoApplied, setPromoApplied] = useState(false);
  const [promoMessage, setPromoMessage] = useState('');

  if (!booking || !seats.length || !passengers.length) {
    return <div className="payment-container"><p>Missing booking or passenger details.</p></div>;
  }

  const {
    busName,
    route,
    departureTime,
    travelDate,
    fare,
    busType,
    userId,
    bookingId
  } = booking;

  const seatCount = seats.length;
  const totalFare = fare * seatCount;
  const promoDiscount = Math.round(totalFare * 0.1);
  const tax = Math.round((totalFare - discount) * 0.05);
  const totalAmount = totalFare - discount + tax;

  const handleApplyPromo = () => {
    const enteredCode = promoCode.trim().toUpperCase();
    if (enteredCode === 'NEWUSER10') {
      setDiscount(promoDiscount);
      setPromoApplied(true);
      setPromoMessage('✅ Promo code applied! You got 10% off.');
    } else {
      setDiscount(0);
      setPromoApplied(false);
      setPromoMessage('❌ Invalid promo code. Try again.');
    }
  };

  const handlePayment = async () => {
    setLoading(true);
    const token = localStorage.getItem("token");

    const paymentPayload = {
      bookingId,
      amount: totalAmount,
      paymentMode: paymentMethod,
      transactionId: "",
      paymentDate: null,
      paymentStatus: null,
      user:  { userId }
    };

    try {
      const res = await axios.post(
        "http://localhost:7000/payments/add",
        paymentPayload,
        { headers: { Authorization: `Bearer ${token}` } }
      );

      if (res.status === 200 || res.status === 201) {
        // Optional: clear localStorage
        localStorage.removeItem("booking");
        localStorage.removeItem("seats");
        localStorage.removeItem("passengers");

        navigate("/payment-success", {
          state: {
            booking: {
              bookingId,
              route,
              travelDate,
              departureTime,
              busName,
              busType,
              passengers,
              seatNumbers: seats,
              farePerSeat: fare,
              seatCount,
              discount,
              tax,
              totalAmount,
              paymentMethod,
            },
          },
        });
      } else {
        navigate("/payment-failure");
      }
    } catch (err) {
      console.error("Payment Error:", err.response?.data || err.message);
      navigate("/payment-failure");
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="payment-container">
      <header className="payment-header">
        <div className="payment-brand"><h2>FastX</h2></div>
        <div className="payment-nav">
          <Link to="/">Home</Link>
          <button onClick={() => navigate('/UserDashboard')}>My Booking History</button>
        </div>
      </header>

      <div className="payment-content">
        <h1>Payment</h1>

        {/* Booking Summary */}
        <section className="payment-section">
          <h3>Booking Summary</h3>
          <div className="summary-grid">
            <p>Route</p><p>{route ? `${route.origin} to ${route.destination}` : 'N/A'}</p>
            <p>Travel Date</p><p>{travelDate}</p>
            <p>Departure Time</p><p>{departureTime}</p>
            <p>Bus Name</p><p>{busName}</p>
            <p>Bus Type</p><p>{busType}</p>
            <p>Seats</p><p>{seats.join(', ')}</p>
          </div>
        </section>

        {/* Passenger Details */}
        <section className="payment-section">
          <h3>Passenger Details</h3>
          {passengers.map((p, index) => (
            <div key={index} className="passenger-card">
              <p><strong>Passenger {index + 1}</strong></p>
              <p>Name: {p.fullName || p.name}</p>
              <p>Age: {p.age}</p>
              <p>Gender: {p.gender}</p>
              {p.phoneNumber && <p>Phone: {p.phoneNumber}</p>}
              {p.email && <p>Email: {p.email}</p>}
              <p>Seat: {seats[index]}</p>
            </div>
          ))}
        </section>

        {/* Fare Section */}
        <section className="payment-section">
          <h3>Fare Breakdown</h3>
          <div className="summary-grid">
            <p>Fare per Seat</p><p>₹{fare}</p>
            <p>Total Fare</p><p>₹{totalFare}</p>
            {promoApplied && (
              <>
                <p>Promo Discount</p><p className="text-green-600">- ₹{discount}</p>
              </>
            )}
            <p>Tax (5%)</p><p>₹{tax}</p>
            <p><strong>Total Amount</strong></p><p><strong>₹{totalAmount}</strong></p>
          </div>
        </section>

        {/* Promo Code */}
        <div className="promo-input">
          <label>Promo Code</label>
          <input
            type="text"
            value={promoCode}
            onChange={(e) => setPromoCode(e.target.value)}
          />
          <button onClick={handleApplyPromo}>Apply</button>
          {promoMessage && <p className="promo-msg">{promoMessage}</p>}
        </div>

        {/* Payment Button */}
        <p>Total Payable: ₹{totalAmount}</p>
        <button onClick={handlePayment} disabled={loading}>
          {loading ? 'Processing...' : 'Pay Now'}
        </button>
      </div>
    </div>
  );
};

export default Payment;
