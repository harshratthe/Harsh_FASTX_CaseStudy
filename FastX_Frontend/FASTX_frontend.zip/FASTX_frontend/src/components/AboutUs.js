import React from 'react';
import { useNavigate } from 'react-router-dom';
import '../styles/aboutus.css';

const AboutUs = () => {
  const navigate = useNavigate();

  return (
    <div className="aboutus-wrapper">
      <header className="aboutus-header">
        <div className="brand" onClick={() => navigate('/')}>
          <h2 className="brand-title">FastX</h2>
        </div>
        <nav className="nav-links">
          <p onClick={() => navigate('/')}>Home</p>
          <p onClick={() => navigate('/Contact')}>Contact</p>
          <p onClick={() => navigate('/Login')}>Sign In</p>
        </nav>
      </header>

      <section className="hero-section">
        <h1 className="hero-title">About FastX</h1>
        <p className="hero-desc">
          FastX is India's fast and reliable online bus ticket booking platform. We simplify travel with secure, quick,
          and easy ticket reservations across thousands of routes.
        </p>
      </section>

      <section className="about-section">
        <h2 className="section-title">Who We Are</h2>
        <p className="section-text">
          FastX was created with a simple vision — to make intercity bus travel easier and more accessible for everyone.
          Whether you're a student, a professional, or a traveler, our platform is designed to save your time and give
          you control over your journey.
        </p>

        <h2 className="section-title">Why Choose FastX</h2>
        <div className="features-grid">
          <div className="feature-card animate-fadeIn">
            <h3>⚡ Quick Bookings</h3>
            <p>Book your tickets in just a few clicks — simple interface and no hassle.</p>
          </div>
          <div className="feature-card animate-fadeIn delay-100">
            <h3>🚌 Real-Time Bus Info</h3>
            <p>Get live schedules and seat availability across all major routes.</p>
          </div>
          <div className="feature-card animate-fadeIn delay-200">
            <h3>🔒 Secure Payments</h3>
            <p>Pay using trusted gateways with instant ticket confirmation.</p>
          </div>
          <div className="feature-card animate-fadeIn delay-300">
            <h3>📞 Customer Support</h3>
            <p>Our support team is available to help you with any booking issues.</p>
          </div>
        </div>
      </section>

      <section className="mission-section">
        <h2 className="section-title text-center">Our Mission</h2>
        <p className="section-text text-center max-w-3xl mx-auto">
          We aim to make every journey simpler, safer, and smarter. FastX is committed to building a travel platform that
          empowers passengers and brings modern convenience to traditional travel.
        </p>
      </section>

      <footer className="footer">
        <div className="footer-links">
          <p>Terms of Use</p>
          <p>Privacy Policy</p>
        </div>
        <p className="text-sm text-[#4574a1]">© 2025 FastX. All rights reserved.</p>
      </footer>
    </div>
  );
};

export default AboutUs;
