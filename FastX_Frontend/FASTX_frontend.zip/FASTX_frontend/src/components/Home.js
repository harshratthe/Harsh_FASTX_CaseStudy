import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { motion } from 'framer-motion';
import '../styles/home.css';
import '../styles/home.css'; // UPDATED CSS FILE FOR ENHANCED LANDING PAGE

const locations = [
  'Pune', 'Mumbai', 'Delhi', 'Bangalore', 'Chennai', 'Hyderabad',
  'Ahmedabad', 'Surat', 'Jaipur', 'Kolkata', 'Lucknow', 'Nagpur'
];

const testimonials = [
  { name: "Priya Sharma", feedback: "FastX made my trip so easy and hassle-free! 🚌✨", location: "Delhi to Jaipur" },
  { name: "Ravi Mehta", feedback: "Loved the clean buses and smooth booking process. Highly recommend! 🌟", location: "Mumbai to Pune" },
  { name: "Anjali Patel", feedback: "Great discounts and on-time service! 🎉🕒", location: "Ahmedabad to Surat" },
  { name: "Karan Singh", feedback: "Impressed by the user-friendly interface. Booked in seconds! 💻🔥", location: "Bangalore to Chennai" }
];

const Home = () => {
  const navigate = useNavigate();
  const [from, setFrom] = useState('');
  const [to, setTo] = useState('');
  const [fromSuggestions, setFromSuggestions] = useState([]);
  const [toSuggestions, setToSuggestions] = useState([]);
  const [showFromSuggestions, setShowFromSuggestions] = useState(false);
  const [showToSuggestions, setShowToSuggestions] = useState(false);
  const [date, setDate] = useState('');
  const [isLoggedIn, setIsLoggedIn] = useState(false);

  useEffect(() => {
    const token = localStorage.getItem('token');
    setIsLoggedIn(!!token);
  }, []);

  const handleSearch = (e) => {
    e.preventDefault();
    navigate(`/SearchBus?from=${from}&to=${to}&date=${date}`);
  };

  const onFromChange = (e) => {
    const val = e.target.value;
    setFrom(val);
    if (val.length > 0) {
      const filtered = locations.filter(loc => loc.toLowerCase().startsWith(val.toLowerCase()));
      setFromSuggestions(filtered);
      setShowFromSuggestions(true);
    } else {
      setShowFromSuggestions(false);
    }
  };

  const onToChange = (e) => {
    const val = e.target.value;
    setTo(val);
    if (val.length > 0) {
      const filtered = locations.filter(loc => loc.toLowerCase().startsWith(val.toLowerCase()));
      setToSuggestions(filtered);
      setShowToSuggestions(true);
    } else {
      setShowToSuggestions(false);
    }
  };

  return (
    <motion.div 
      className="home-wrapper-alt" 
      initial={{ opacity: 0 }} 
      animate={{ opacity: 1 }} 
      transition={{ duration: 1.2 }}>

      <motion.header 
        className="home-header-alt" 
        initial={{ y: -100, opacity: 0 }} 
        animate={{ y: 0, opacity: 1 }} 
        transition={{ delay: 0.3, duration: 1 }}>

        <div className="brand">
          <div className="brand-icon-alt">
            <svg viewBox="0 0 48 48" fill="none" xmlns="http://www.w3.org/2000/svg">
              <path d="M44 4H30.6666V17.3334H17.3334V30.6666H4V44H44V4Z" fill="currentColor"></path>
            </svg>
          </div>
          <h2 className="brand-title-alt">FastX</h2>
        </div>

        <div className="nav-links">
          <motion.button whileHover={{ scale: 1.1 }} transition={{ duration: 0.3 }} className="nav-button-alt" onClick={() => navigate('/AboutUs')}>About Us</motion.button>
          <motion.button whileHover={{ scale: 1.1 }} transition={{ duration: 0.3 }} className="nav-button-alt" onClick={() => navigate('/Contact')}>Contact</motion.button>
          {isLoggedIn ? (
            <motion.button whileHover={{ scale: 1.1 }} transition={{ duration: 0.3 }} className="nav-button-alt" onClick={() => navigate('/UserDashboard')}>Your Profile</motion.button>
          ) : (
            <motion.button whileHover={{ scale: 1.1 }} transition={{ duration: 0.3 }} className="nav-button-alt" onClick={() => navigate('/Login')}>Sign In / Sign Up</motion.button>
          )}
        </div>
      </motion.header>

      <motion.div 
        className="hero-text-alt"
        initial={{ opacity: 0, y: 50 }} 
        animate={{ opacity: 1, y: 0 }} 
        transition={{ delay: 0.5, duration: 1 }}>
        <h1 className="hero-heading-alt">Book Your Bus Ticket Now</h1>
        <h2 className="hero-subheading-alt">Search and book from 5000+ routes across India.</h2>
      </motion.div>

      <motion.form 
        className="search-form-alt" 
        onSubmit={handleSearch} 
        autoComplete="off"
        initial={{ opacity: 0 }} 
        animate={{ opacity: 1 }} 
        transition={{ delay: 0.6, duration: 1 }}>

        <div className="relative">
          <input type="text" name="from" placeholder="From" className="search-input" value={from} onChange={onFromChange} onBlur={() => setTimeout(() => setShowFromSuggestions(false), 150)} onFocus={() => from.length > 0 && setShowFromSuggestions(true)} required />
          {showFromSuggestions && fromSuggestions.length > 0 && (
            <ul className="suggestion-list">
              {fromSuggestions.map((loc, i) => (
                <li key={i} className="suggestion-item" onClick={() => { setFrom(loc); setShowFromSuggestions(false); }}>{loc}</li>
              ))}
            </ul>
          )}
        </div>

        <div className="relative">
          <input type="text" name="to" placeholder="To" className="search-input" value={to} onChange={onToChange} onBlur={() => setTimeout(() => setShowToSuggestions(false), 150)} onFocus={() => to.length > 0 && setShowToSuggestions(true)} required />
          {showToSuggestions && toSuggestions.length > 0 && (
            <ul className="suggestion-list">
              {toSuggestions.map((loc, i) => (
                <li key={i} className="suggestion-item" onClick={() => { setTo(loc); setShowToSuggestions(false); }}>{loc}</li>
              ))}
            </ul>
          )}
        </div>

        <input type="date" name="date" className="search-input" value={date} onChange={(e) => setDate(e.target.value)} required />

        <div className="flex justify-center">
          <motion.button 
            whileHover={{ scale: 1.05 }} 
            whileTap={{ scale: 0.95 }} 
            type="submit" 
            className="search-button-alt primary-action"
            transition={{ duration: 0.3 }}>
            Search Bus
          </motion.button>
        </div>
      </motion.form>

      <motion.div 
        className="testimonial-section" 
        initial={{ opacity: 0 }} 
        whileInView={{ opacity: 1 }} 
        viewport={{ once: true }} 
        transition={{ delay: 0.8, duration: 1.2 }}>

        <h3 className="testimonial-title-alt">💬 What Our Users Say</h3>
        <div className="testimonial-grid">
          {testimonials.map((t, index) => (
            <motion.div 
              className="testimonial-card-alt" 
              key={index}
              whileHover={{ scale: 1.03 }}
              initial={{ opacity: 0, y: 30 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.8, delay: index * 0.15 }}>
              <p className="testimonial-text">"{t.feedback}"</p>
              <p className="testimonial-name">– {t.name}</p>
              <p className="testimonial-route">🗺 {t.location}</p>
            </motion.div>
          ))}
        </div>
      </motion.div>

    </motion.div>
  );
};

export default Home;
