import React from 'react';
import '../styles/PaymentFailed.css';
import { useNavigate } from 'react-router-dom';

const PaymentFailed = () => {
  const navigate = useNavigate();

  const handleRetry = () => {
    window.location.reload(); // Reload current page to retry
  };

  const handleChangeMethod = () => {
    navigate('/payment'); // Go back to payment page
  };

  const handleBackToSeats = () => {
    navigate('/available-buses'); // Redirect to seat selection
  };

  return (
    <div className="payment-failed-container">
      <header className="payment-failed-header">
        <div className="brand">
          <svg viewBox="0 0 48 48" fill="none" xmlns="http://www.w3.org/2000/svg">
            <path d="M44 4H30.6666V17.3334H17.3334V30.6666H4V44H44V4Z" fill="currentColor"></path>
          </svg>
          <h2>FastX</h2>
        </div>
        <div className="nav">
          <a href="/">Home</a>
          <button onClick={() => navigate('/UserDashboard')}>My Booking History</button>
          <div className="avatar"></div>
        </div>
      </header>

      <div className="payment-failed-content">
        <h2>Payment Failed</h2>
        <div className="image-container">
          <div className="failed-image"></div>
        </div>
        <p className="msg">Oops! Your Payment Could Not Be Processed.</p>
        <p className="sub-msg">
          There was an issue processing your payment. This could be due to connectivity problems, card issues,
          or a UPI timeout. Please try again or choose a different payment method.
        </p>
        <div className="btn-group">
          <button onClick={handleRetry}>Try Again</button>
          <button onClick={handleChangeMethod}>Change Payment Method</button>
        </div>
        <p className="link" onClick={handleBackToSeats}>Back to Seat Selection</p>
      </div>
    </div>
  );
};

export default PaymentFailed;
