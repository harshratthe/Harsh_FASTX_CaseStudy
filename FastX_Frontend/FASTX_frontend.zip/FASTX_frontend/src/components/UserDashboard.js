import React, { useEffect, useState } from 'react';
import axios from 'axios';
import '../styles/UserDashboard.css';

const UserDashboard = () => {
  const [user, setUser] = useState({});
  const [bookings, setBookings] = useState([]);
  const [editMode, setEditMode] = useState(false);
  const [passwordMode, setPasswordMode] = useState(false);
  const [formData, setFormData] = useState({});
  const [newPassword, setNewPassword] = useState('');

  useEffect(() => {
    const token = localStorage.getItem('token');
    const storedUser = JSON.parse(localStorage.getItem('user'));
    if (!token || !storedUser) return;

    setUser(storedUser);
    setFormData(storedUser);
    const userId = storedUser.userId;

    axios.get(`http://localhost:7000/bookings/getbookingbyuserid/${userId}`, {
      headers: { Authorization: `Bearer ${token}` },
    })
      .then(res => setBookings(res.data))
      .catch(err => console.error('Bookings fetch error:', err));
  }, []);

  const handleEditChange = e => {
    setFormData({ ...formData, [e.target.name]: e.target.value });
  };

  const handleProfileUpdate = () => {
    const token = localStorage.getItem('token');
    axios.put(`http://localhost:7000/users/update/${user.userId}`, formData, {
      headers: { Authorization: `Bearer ${token}` }
    })
      .then(res => {
        setUser(res.data);
        localStorage.setItem('user', JSON.stringify(res.data));
        setEditMode(false);
        alert("Profile updated successfully.");
      })
      .catch(err => alert("Update failed."));
  };

  const handlePasswordUpdate = () => {
    const token = localStorage.getItem('token');
    const updated = { ...user, password: newPassword };
    axios.put(`http://localhost:7000/users/update/${user.userId}`, updated, {
      headers: { Authorization: `Bearer ${token}` }
    })
      .then(() => {
        setPasswordMode(false);
        alert("Password updated successfully.");
      })
      .catch(err => alert("Password update failed."));
  };
 const handleLogout = () => {
    localStorage.clear();
    window.location.href = '/';
  };
  return (
    <div className="dashboard-container">
      <header className="dashboard-header">
        <div className="brand">
          <svg viewBox="0 0 48 48" fill="none">
            <path d="M44 4H30.6666V17.3334H17.3334V30.6666H4V44H44V4Z" fill="currentColor" />
          </svg>
          <h2>FastX</h2>
        </div>
        <div className="nav"><a href="/">Home</a></div>
      </header>

      <main className="dashboard-content">
        <h1>User Dashboard</h1>

        <section>
          <h2>My Booking History</h2>
          <div className="booking-table">
            <table>
              <thead>
                <tr>
                  <th>Bus</th><th>Route</th><th>Date</th><th>Amount</th><th>Status</th>
                </tr>
              </thead>
              <tbody>
                {bookings.length ? bookings.map((b, i) => (
                  <tr key={i}>
                    <td>{b.bus?.busName || 'N/A'}</td>
                    <td>{b.route?.origin} to {b.route?.destination}</td>
                    <td>{b.bookingDate ? new Date(b.bookingDate).toLocaleDateString() : 'N/A'}</td>
                    <td>₹{b.totalAmount || 0}</td>
                    <td><span className="status-btn">{b.bookingStatus || 'Pending'}</span></td>
                  </tr>
                )) : (
                  <tr><td colSpan="6">No bookings found.</td></tr>
                )}
              </tbody>
            </table>
          </div>
        </section>

        <section className="profile-section">
          <h2>My Profile</h2>
          {!editMode ? (
            <div className="profile-grid">
              <p>Name</p><p>{user.fullName || user.userName || 'N/A'}</p>
              <p>Email</p><p>{user.email || 'N/A'}</p>
              <p>Contact</p><p>{user.phone || 'N/A'}</p>
            </div>
          ) : (
            <div className="profile-grid">
              <p>Name</p>
              <input name="userName" value={formData.userName} onChange={handleEditChange} />
              <p>Email</p>
              <input name="email" value={formData.email} onChange={handleEditChange} />
              <p>Phone</p>
              <input name="phone" value={formData.phone} onChange={handleEditChange} />
            </div>
          )}

          <div className="profile-actions">
            {!editMode ? (
              <button onClick={() => setEditMode(true)}>Edit Profile</button>
            ) : (
              <>
                <button onClick={handleProfileUpdate}>Save</button>
                <button onClick={() => setEditMode(false)}>Cancel</button>
              </>
            )}
            {!passwordMode ? (
              <button className="primary" onClick={() => setPasswordMode(true)}>Update Password</button>
            ) : (
              <>
                <input
                  type="password"
                  placeholder="New Password"
                  value={newPassword}
                  onChange={e => setNewPassword(e.target.value)}
                />
                <button onClick={handlePasswordUpdate}>Save Password</button>
                <button onClick={() => setPasswordMode(false)}>Cancel</button>
              </>
            )}
          </div>
        </section>

        <button className="logout-btn" onClick={handleLogout}>
          Logout
        </button>
      </main>
    </div>
  );
};

export default UserDashboard;
