import React from 'react';
import { Routes, Route } from 'react-router-dom';
import Login from '../components/Loginpage';
import SignUp from '../components/SignUp';
import Home from '../components/Home';
import AboutUs from '../components/AboutUs';
import Contact from '../components/Contact';
import SearchBus from '../components/SearchBus';
import BookSeat from '../components/BookSeat';
import OperatorDashboard from '../components/OperatorDashboard';
import AdminDashboard from '../components/Admindashboard';
import PassengerDetails from '../components/PassengerDetails';
import Payment from '../components/Payment';
import BookingConfirmed from '../components/BookingConfirmed';
import PaymentFailed from '../components/PaymentFailed';
import UserDashboard from '../components/UserDashboard';

const AppRoutes = () => {
  return (
    <Routes>
      <Route path="/" element={<Home />} />

     // <Route path="/login" element={<Login/>} />
      <Route path="/signup" element={<SignUp />} />
     <Route path="/aboutus" element={<AboutUs />} />
      <Route path="/contact" element={<Contact />} />
      <Route path="/searchbus" element={<SearchBus />} />
      <Route path="/BookSeat" element={<BookSeat/>} />
      <Route path="/BookSeat/:busId" element={<BookSeat />} />

      <Route path="/BusOperatorDashboard" element={<OperatorDashboard/>} />
      <Route path="/AdminDashboard" element={<AdminDashboard/>} />
      <Route path="/PassengerDetails" element={<PassengerDetails/>} />
       <Route path="/payment" element={<Payment/>} />
      <Route path="payment-success" element={<BookingConfirmed/>} />
      <Route path="payment-failure" element={<PaymentFailed/>} />
      <Route path="/UserDashboard" element={<UserDashboard/>} />







      




   
    </Routes>
  );
};

export default AppRoutes;