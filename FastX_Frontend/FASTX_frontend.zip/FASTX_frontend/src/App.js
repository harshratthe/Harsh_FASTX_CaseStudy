import logo from './logo.svg';
import './App.css';

import LoginPage from './components/Loginpage';
import ForgotPassword from './components/ForgotPassword';
import AppRoutes from './routes/AppRoutes';
import { BrowserRouter, Router } from 'react-router-dom';

function App() {
  return (

      <BrowserRouter>
      <AppRoutes />
      </BrowserRouter>
    

  );
}

export default App;
