// src/utils/auth/auth.js

export const saveToken = (token) => {
  localStorage.setItem("fastx_token", token);
};

export const getToken = () => {
  return localStorage.getItem("fastx_token");
};

export const removeToken = () => {
  localStorage.removeItem("fastx_token");
};

export const isLoggedIn = () => {
  return !!getToken();
};

export const getAuthHeader = () => {
  const token = getToken();
  return token ? { Authorization: `Bearer ${token}` } : {};
};
