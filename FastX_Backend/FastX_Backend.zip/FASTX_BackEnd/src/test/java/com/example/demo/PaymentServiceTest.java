package com.example.demo;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

import com.example.demo.DTO.PaymentDTO;
import com.example.demo.Entity.Booking;
import com.example.demo.Entity.Payment;
import com.example.demo.Entity.User;
import com.example.demo.Enum.PaymentStatus;
import com.example.demo.Exceptions.BookingNotFoundException;
import com.example.demo.Exceptions.PaymentNotFoundException;
import com.example.demo.Exceptions.UserNotFoundException;
import com.example.demo.Repositories.BookingRepository;
import com.example.demo.Repositories.PaymentRepository;
import com.example.demo.Repositories.UserRepository;
import com.example.demo.Service_Implementation.PaymentService_Implementation;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.*;
import org.springframework.boot.test.context.SpringBootTest;

import java.time.LocalDateTime;
import java.util.*;

@SpringBootTest
public class PaymentServiceTest {

    @InjectMocks
    private PaymentService_Implementation paymentService;

    @Mock
    private UserRepository userRepo;

    @Mock
    private BookingRepository bookingRepo;

    @Mock
    private PaymentRepository paymentRepo;

    private Payment mockPayment;
    private Booking mockBooking;
    private User mockUser;

    @BeforeEach
    void setUp() {
        MockitoAnnotations.openMocks(this);

        mockUser = new User();
        mockUser.setUserId(1);

        mockBooking = new Booking();
        mockBooking.setBookingId(10);

        mockPayment = new Payment();
        mockPayment.setPaymentId(100);
        mockPayment.setAmount(500.0);
        mockPayment.setPaymentMode("UPI");
        mockPayment.setTransactionId("abc123");
        mockPayment.setPaymentStatus(PaymentStatus.SUCCESS);
        mockPayment.setPaymentDate(LocalDateTime.now());
        mockPayment.setBooking(mockBooking);
        mockPayment.setUser(mockUser);
    }

    

    

   

    @Test
    void testGetPaymentById_Success() throws PaymentNotFoundException {
        when(paymentRepo.findById(100)).thenReturn(Optional.of(mockPayment));

        PaymentDTO result = paymentService.getPaymentById(100);
        assertEquals(500.0, result.getAmount());
        assertEquals("UPI", result.getPaymentMode());
    }

    @Test
    void testGetPaymentById_NotFound() {
        when(paymentRepo.findById(999)).thenReturn(Optional.empty());
        assertThrows(PaymentNotFoundException.class, () -> {
            paymentService.getPaymentById(999);
        });
    }

    @Test
    void testGetAllPayments() {
        List<Payment> payments = Arrays.asList(mockPayment);
        when(paymentRepo.findAll()).thenReturn(payments);

        List<PaymentDTO> result = paymentService.getAllPayments();
        assertEquals(1, result.size());
        assertEquals(500.0, result.get(0).getAmount());
    }

    @Test
    void testGetPaymentsByUserId() {
        List<Payment> payments = Arrays.asList(mockPayment);
        when(paymentRepo.findByUser_UserId(1)).thenReturn(payments);

        List<PaymentDTO> result = paymentService.getPaymentsByUserId(1);
        assertEquals(1, result.size());
        assertEquals(500.0, result.get(0).getAmount());
    }

    @Test
    void testUpdatePayment_Success() {
        PaymentDTO dto = new PaymentDTO();
        dto.setAmount(999.0);
        dto.setPaymentDate(LocalDateTime.now());
        dto.setPaymentMode("NETBANKING");

        when(paymentRepo.findById(100)).thenReturn(Optional.of(mockPayment));
        when(paymentRepo.save(any(Payment.class))).thenReturn(mockPayment);

        assertDoesNotThrow(() -> paymentService.updatePayment(100, dto));
    }

    @Test
    void testUpdatePayment_NotFound() {
        PaymentDTO dto = new PaymentDTO();
        when(paymentRepo.findById(999)).thenReturn(Optional.empty());

        assertThrows(PaymentNotFoundException.class, () -> {
            paymentService.updatePayment(999, dto);
        });
    }

    @Test
    void testRefundPayment_Success() {
        when(paymentRepo.findById(100)).thenReturn(Optional.of(mockPayment));
        assertDoesNotThrow(() -> paymentService.refundPayment(100));
        verify(paymentRepo, times(1)).save(any(Payment.class));
    }

    @Test
    void testRefundPayment_NotFound() {
        when(paymentRepo.findById(999)).thenReturn(Optional.empty());

        assertThrows(PaymentNotFoundException.class, () -> {
            paymentService.refundPayment(999);
        });
    }
}