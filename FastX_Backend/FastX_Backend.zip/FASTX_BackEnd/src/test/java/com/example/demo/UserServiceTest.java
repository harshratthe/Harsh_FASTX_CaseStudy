package com.example.demo;





import com.example.demo.DTO.UserDTO;
import com.example.demo.Entity.User;
import com.example.demo.Enum.UserRole;
import com.example.demo.Exceptions.EmailAlreadyExistsException;
import com.example.demo.Exceptions.InvalidCredentialsException;
import com.example.demo.Exceptions.UserNotFoundException;
import com.example.demo.Mappers.UserMapper;
import com.example.demo.Repositories.BookingRepository;
import com.example.demo.Repositories.UserRepository;
import com.example.demo.Service_Implementation.UserService_Implementation;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.*;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.security.crypto.password.PasswordEncoder;

import java.util.Optional;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

@SpringBootTest
public class UserServiceTest {

    @InjectMocks
    private UserService_Implementation userService;

    @Mock
    private UserRepository userRepo;

    @Mock
    private BookingRepository bookingRepo;

    @Mock
    private PasswordEncoder passwordEncoder;

    private User mockUser;

    @BeforeEach
    void setUp() {
        MockitoAnnotations.openMocks(this);
        mockUser = new User();
        mockUser.setUserId(1);
        mockUser.setUserName("John");
        mockUser.setEmail("john@example.com");
        mockUser.setPassword("encodedpass");
        mockUser.setPhone("1234567890");
        mockUser.setAddress("Test Street");
        mockUser.setRole(UserRole.PASSENGER);
    }

    @Test
    void testRegisterUser() throws EmailAlreadyExistsException {
        UserDTO inputDto = new UserDTO(0, "John", "john@example.com", "rawpass", "1234567890", "Test Street", UserRole.PASSENGER);

        when(userRepo.existsByEmail("john@example.com")).thenReturn(false);
        when(passwordEncoder.encode("rawpass")).thenReturn("encodedpass");
        when(userRepo.save(any(User.class))).thenAnswer(invocation -> invocation.getArgument(0));

        UserDTO result = userService.registerUser(inputDto);
        assertEquals("John", result.getUserName());
        assertEquals("john@example.com", result.getEmail());
    }

    @Test
    void testLoginSuccess() throws UserNotFoundException, InvalidCredentialsException {
        when(userRepo.findByEmail("john@example.com")).thenReturn(mockUser);
        when(passwordEncoder.matches("rawpass", "encodedpass")).thenReturn(true);

        UserDTO result = userService.login("john@example.com", "rawpass");
        assertEquals("John", result.getUserName());
        assertEquals("john@example.com", result.getEmail());
    }

    @Test
    void testGetUserById() throws UserNotFoundException {
        when(userRepo.findById(1)).thenReturn(Optional.of(mockUser));

        UserDTO result = userService.getUserById(1);
        assertEquals("John", result.getUserName());
    }

    @Test
    void testGetUserById_NotFound() {
        when(userRepo.findById(999)).thenReturn(Optional.empty());

        assertThrows(UserNotFoundException.class, () -> {
            userService.getUserById(999);
        });
    }

    @Test
    void testLogin_InvalidPassword() {
        when(userRepo.findByEmail("john@example.com")).thenReturn(mockUser);
        when(passwordEncoder.matches("wrongpass", "encodedpass")).thenReturn(false);

        assertThrows(InvalidCredentialsException.class, () -> {
            userService.login("john@example.com", "wrongpass");
        });
    }

    @Test
    void testLogin_UserNotFound() {
        when(userRepo.findByEmail("notfound@example.com")).thenReturn(null);

        assertThrows(UserNotFoundException.class, () -> {
            userService.login("notfound@example.com", "any");
        });
    }
}
