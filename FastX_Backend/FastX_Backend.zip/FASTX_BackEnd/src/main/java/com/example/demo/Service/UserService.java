package com.example.demo.Service;

import java.util.List;

import com.example.demo.DTO.BookingDTO;
import com.example.demo.DTO.UserDTO;
import com.example.demo.Enum.UserRole;
import com.example.demo.Exceptions.EmailAlreadyExistsException;
import com.example.demo.Exceptions.InvalidCredentialsException;
import com.example.demo.Exceptions.UserNotFoundException;

public interface UserService  {

	
    UserDTO registerUser(UserDTO userDto) throws EmailAlreadyExistsException;

   
    UserDTO login(String email, String password) throws UserNotFoundException, InvalidCredentialsException;

   
    UserDTO loginAdmin(String email, String password) throws UserNotFoundException, InvalidCredentialsException;

    UserDTO loginOperator(String email, String password) throws UserNotFoundException, InvalidCredentialsException;


   
    UserDTO updateUser(int id, UserDTO userDto) throws UserNotFoundException;

   
    String deleteUser(int id) throws UserNotFoundException;


    UserDTO getUserById(int id) throws UserNotFoundException;


    List<UserDTO> getUsersByRole(UserRole role);

  
    List<UserDTO> getAllUsers();

    
    UserDTO viewProfile(int userId) throws UserNotFoundException;

    String forgotPassword(String email) throws UserNotFoundException;

  
    List<UserDTO> getAllOperators();

   
    String deleteOperator(int operatorId) throws UserNotFoundException;
	
}
