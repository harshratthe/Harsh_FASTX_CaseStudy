package com.example.demo.Controller;

import java.time.LocalDate;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo.DTO.BusDTO;
import com.example.demo.Enum.Amenity;
import com.example.demo.Enum.BusType;
import com.example.demo.Exceptions.BusNotFoundException;
import com.example.demo.Exceptions.RouteNotFoundException;
import com.example.demo.Exceptions.UserNotFoundException;
import com.example.demo.Service.BusService;

import jakarta.validation.Valid;

@RestController
@CrossOrigin("http://localhost:3000")
@RequestMapping("/buses")
public class BusController {

	@Autowired
    private BusService busService;
	
	@PreAuthorize("hasRole('OPERATOR')")
	 @PostMapping("/add")
	    public ResponseEntity<BusDTO> addBus(@Valid @RequestBody BusDTO busDto) throws RouteNotFoundException, UserNotFoundException {
	        BusDTO saved = busService.addBus(busDto);
	        HttpHeaders headers = new HttpHeaders();
	        headers.add("info", "Bus added successfully");
	        return new ResponseEntity<>(saved, headers, HttpStatus.CREATED);
	    }

    // 1. Get all buses
    @GetMapping("/all")
    public ResponseEntity<List<BusDTO>> getAllBuses() {
        List<BusDTO> buses = busService.getAllBuses();
        HttpHeaders headers = new HttpHeaders();
        headers.add("info", "All buses fetched successfully");
        return new ResponseEntity<>(buses, headers, HttpStatus.OK);
    }

    // 2. Get bus by ID
    @GetMapping("/getbusbyid/{id}")
    public ResponseEntity<BusDTO> getBusById(@PathVariable int id) throws BusNotFoundException {
        BusDTO bus = busService.getBusById(id);
        HttpHeaders headers = new HttpHeaders();
        headers.add("info", "Bus fetched by ID");
        return new ResponseEntity<>(bus, headers, HttpStatus.OK);
    }

    // 3. Get all buses for a specific route
    @GetMapping("/route/{routeId}")
    public ResponseEntity<List<BusDTO>> getBusesByRoute(@PathVariable int routeId) {
        List<BusDTO> buses = busService.getBusesByRoute(routeId);
        HttpHeaders headers = new HttpHeaders();
        headers.add("info", "Buses fetched by route ID");
        return new ResponseEntity<>(buses, headers, HttpStatus.OK);
    }

    // 4. Search buses by origin, destination and date
    @GetMapping("/route/{origin}/{destination}/{date}")
    public ResponseEntity<List<BusDTO>> getBusesByOriginDestinationDate(
            @PathVariable String origin,
            @PathVariable String destination,
            @PathVariable String date) {
        List<BusDTO> buses = busService.searchBusesByRouteAndDate(origin, destination, LocalDate.parse(date));
        HttpHeaders headers = new HttpHeaders();
        headers.add("info", "Buses fetched by origin, destination, and date");
        return new ResponseEntity<>(buses, headers, HttpStatus.OK);
    }

    // 5. Get buses by multiple amenities
    @PostMapping("/amenities")
    public ResponseEntity<List<BusDTO>> getBusesByAmenities(@RequestBody List<Amenity> amenities) {
        List<BusDTO> buses = busService.getBusesByAmenities(amenities);
        HttpHeaders headers = new HttpHeaders();
        headers.add("info", "Buses fetched by amenities");
        return new ResponseEntity<>(buses, headers, HttpStatus.OK);
    }

    // 6. Search buses by type, date
    @GetMapping("/search")
    public ResponseEntity<List<BusDTO>> searchBusesByRouteAndDate(
            @RequestParam String origin,
            @RequestParam String destination,
            @RequestParam String date) {

        List<BusDTO> buses = busService.searchBusesByRouteAndDate(origin, destination, LocalDate.parse(date));
        HttpHeaders headers = new HttpHeaders();
        headers.add("info", "Buses searched by route and date");
        return new ResponseEntity<>(buses, headers, HttpStatus.OK);
    }

    @DeleteMapping("/delete/{id}")
    public ResponseEntity<String> deleteBus(@PathVariable int id) throws BusNotFoundException {
        busService.deleteBus(id);
        return ResponseEntity.ok("🗑️ Bus deleted successfully!");
    }

    // UPDATE
    @PutMapping("/update/{id}")
    public ResponseEntity<BusDTO> updateBus(@PathVariable int id, @RequestBody @Valid BusDTO busDto) throws UserNotFoundException, RouteNotFoundException, BusNotFoundException {
        BusDTO updatedBus = busService.updateBus(id, busDto);
        return new ResponseEntity<>(updatedBus, HttpStatus.OK);
    }
	
    
    
    
    
    
    
    
    
	
}
