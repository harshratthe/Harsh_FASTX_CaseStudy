package com.example.demo.util;

import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.function.Function;

import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.stereotype.Component;

import com.example.demo.Entity.User;

import io.jsonwebtoken.Claims;
import io.jsonwebtoken.Jwts;
import io.jsonwebtoken.SignatureAlgorithm;

@Component
public class JwtUtil {

    private final String SECRET_KEY = "76019FFB5046AB360A92D9DFA85F6B905D83807AEE56CA3C20DAD423725378022C8FAEB246E32EB70A38671D5D6DCE059084C1402F3E957DD1E9366C12ACBA57";

    public String extractUsername(String token) {
        return extractClaim(token, Claims::getSubject);
    }

    public Date extractExpiration(String token) {
        return extractClaim(token, Claims::getExpiration);
    }

    public <T> T extractClaim(String token, Function<Claims, T> claimsResolver) {
        final Claims claims = extractAllClaims(token);
        return claimsResolver.apply(claims);
    }

    public Claims extractAllClaims(String token) {
        return Jwts
                .parser()
                .setSigningKey(SECRET_KEY)
                .parseClaimsJws(token)
                .getBody();
    }

    private Boolean isTokenExpired(String token) {
        return extractExpiration(token).before(new Date());
    }

    // 🔧 ✅ This is the updated method that accepts your User entity
    public String generateToken(User user) {
        Map<String, Object> claims = new HashMap<>();

        // 🔒 Add roles to claims (Spring Security needs "ROLE_" prefix)
        claims.put("roles", List.of("ROLE_" + user.getRole().name()));

        return createToken(claims, user.getEmail()); // use email as subject
    }

    private String createToken(Map<String, Object> claims, String subject) {
        long expirationMillis = 1000 * 60 * 60 * 10; // 10 hours

        return Jwts
                .builder()
                .setClaims(claims)
                .setSubject(subject)
                .setIssuedAt(new Date(System.currentTimeMillis()))
                .setExpiration(new Date(System.currentTimeMillis() + expirationMillis))
                .signWith(SignatureAlgorithm.HS256, SECRET_KEY)
                .compact();
    }

    public Boolean isTokenValid(String token, UserDetails userDetails) {
        final String username = extractUsername(token);
        return (username.equals(userDetails.getUsername()) && !isTokenExpired(token));
    }
}
