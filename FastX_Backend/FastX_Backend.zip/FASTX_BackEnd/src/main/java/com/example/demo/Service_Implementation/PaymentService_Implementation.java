package com.example.demo.Service_Implementation;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.List;
import java.util.UUID;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.demo.DTO.PaymentDTO;
import com.example.demo.Entity.Booking;
import com.example.demo.Entity.Payment;
import com.example.demo.Entity.User;
import com.example.demo.Enum.BookingStatus;
import com.example.demo.Enum.PaymentStatus;
import com.example.demo.Exceptions.BookingNotFoundException;
import com.example.demo.Exceptions.PaymentNotFoundException;
import com.example.demo.Exceptions.UserNotFoundException;
import com.example.demo.Mappers.PaymentMapper;
import com.example.demo.Repositories.BookingRepository;
import com.example.demo.Repositories.BusRepository;
import com.example.demo.Repositories.PaymentRepository;
import com.example.demo.Repositories.RouteRepository;
import com.example.demo.Repositories.SeatRepository;
import com.example.demo.Repositories.UserRepository;
import com.example.demo.Service.PaymentService;

@Service
public class PaymentService_Implementation implements PaymentService {

	@Autowired
    private UserRepository userRepo;

    @Autowired
    private BookingRepository bookingRepo;

    @Autowired
    private BusRepository busRepo;

    @Autowired
    private SeatRepository seatRepo;

    @Autowired
    private RouteRepository routeRepo;

	@Autowired
    private PaymentRepository paymentRepo;

	
	
	@Override
	public void makePayment(PaymentDTO paymentDto) throws BookingNotFoundException, UserNotFoundException {
		int bookingId = paymentDto.getBookingId();
	    Booking booking = bookingRepo.findById(bookingId)
	        .orElseThrow(() -> new BookingNotFoundException("Booking not found with ID: " + bookingId));

	    // Fetch user
	    int userId = paymentDto.getUser().getUserId();
	    User user = userRepo.findById(userId)
	        .orElseThrow(() -> new UserNotFoundException("User not found with ID: " + userId));

	    // Create payment
	    Payment payment = new Payment();
	    payment.setAmount(paymentDto.getAmount());
	    payment.setPaymentMode(paymentDto.getPaymentMode());
	    payment.setTransactionId(
	        (paymentDto.getTransactionId() != null && !paymentDto.getTransactionId().isEmpty())
	            ? paymentDto.getTransactionId()
	            : UUID.randomUUID().toString()
	    );
	    payment.setPaymentDate(
	        (paymentDto.getPaymentDate() != null)
	            ? paymentDto.getPaymentDate()
	            : LocalDateTime.now()
	    );

	    // Set status
	    if (payment.getAmount() > 0) {
	        payment.setPaymentStatus(PaymentStatus.SUCCESS);
	    } else {
	        payment.setPaymentStatus(PaymentStatus.FAILED);
	    }

	    // Set relationships
	    payment.setBooking(booking);
	    payment.setUser(user);

	    // Save
	    paymentRepo.save(payment);
		
	}

	@Override
	public PaymentDTO getPaymentById(int paymentId) throws PaymentNotFoundException {
		 Payment payment = paymentRepo.findById(paymentId).orElse(null);
	        if (payment == null) {
	            throw new PaymentNotFoundException("Payment not found with ID: " + paymentId);
	        }
	        return PaymentMapper.toDto(payment);
	}

	@Override
	public List<PaymentDTO> getAllPayments() {
		 List<Payment> payments = paymentRepo.findAll();
	        return payments.stream()
	                .map(payment -> PaymentMapper.toDto(payment))
	                .collect(Collectors.toList());
	}

	@Override
	public List<PaymentDTO> getPaymentsByUserId(int userId) {
		 List<Payment> payments = paymentRepo.findByUser_UserId(userId);
	        return payments.stream()
	                .map(payment -> PaymentMapper.toDto(payment))
	                .collect(Collectors.toList());
	}

	@Override
	public void updatePayment(int paymentId, PaymentDTO paymentDto) throws PaymentNotFoundException {
		Payment existing = paymentRepo.findById(paymentId).orElse(null);
        if (existing == null) {
            throw new PaymentNotFoundException("Payment not found with ID: " + paymentId);
        }

        existing.setAmount(paymentDto.getAmount());
        existing.setPaymentDate(paymentDto.getPaymentDate());
        existing.setPaymentMode(paymentDto.getPaymentMode());

        paymentRepo.save(existing);
		
	}

	@Override
	public void refundPayment(int paymentId) throws PaymentNotFoundException {
		Payment payment = paymentRepo.findById(paymentId).orElse(null);
        if (payment == null) {
            throw new PaymentNotFoundException("Payment not found with ID: " + paymentId);
        }

        payment.setPaymentStatus(PaymentStatus.REFUNDED);
        paymentRepo.save(payment);
    }
		
	}


