package com.example.demo.Service;

import java.util.List;

import com.example.demo.DTO.PassengerDTO;
import com.example.demo.Exceptions.BookingNotFoundException;
import com.example.demo.Exceptions.UserNotFoundException;

public interface PassengerService {

	void addPassenger(PassengerDTO passengerDto) throws BookingNotFoundException;

    PassengerDTO getPassengerById(int id) throws UserNotFoundException;

    List<PassengerDTO> getPassengersByBookingId(int bookingId) throws BookingNotFoundException;

    void updatePassenger(int id, PassengerDTO passengerDto) throws UserNotFoundException;

    void deletePassenger(int id) throws UserNotFoundException;
	
	
}
