package com.example.demo.Exceptions;

public class PaymentNotFoundException extends Exception{

	 public PaymentNotFoundException(String message) {
	        super(message);
	    }
	
	
}
