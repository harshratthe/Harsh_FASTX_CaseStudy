package com.example.demo.Controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo.DTO.PassengerDTO;
import com.example.demo.Exceptions.BookingNotFoundException;
import com.example.demo.Exceptions.UserNotFoundException;
import com.example.demo.Service.PassengerService;

import jakarta.validation.Valid;

@RestController
@CrossOrigin("http://localhost:3000")
@RequestMapping("/passengers")
public class PassengerController {

	 @Autowired
	    private PassengerService passengerService;

	    @PostMapping("/add")
	    public ResponseEntity<String> addPassenger(@Valid @RequestBody PassengerDTO passengerDto) throws BookingNotFoundException {
	        passengerService.addPassenger(passengerDto);
	        return new ResponseEntity<>("Passenger added successfully", HttpStatus.CREATED);
	    }

	    @GetMapping("/{id}")
	    public ResponseEntity<PassengerDTO> getPassengerById(@PathVariable int id) throws UserNotFoundException {
	        PassengerDTO passenger = passengerService.getPassengerById(id);
	        return new ResponseEntity<>(passenger, HttpStatus.OK);
	    }

	    @GetMapping("/booking/{bookingId}")
	    public ResponseEntity<List<PassengerDTO>> getPassengersByBooking(@PathVariable int bookingId) throws BookingNotFoundException {
	        List<PassengerDTO> passengers = passengerService.getPassengersByBookingId(bookingId);
	        return new ResponseEntity<>(passengers, HttpStatus.OK);
	    }

	    @PutMapping("/update/{id}")
	    public ResponseEntity<String> updatePassenger(@PathVariable int id, @Valid @RequestBody PassengerDTO passengerDto) throws UserNotFoundException {
	        passengerService.updatePassenger(id, passengerDto);
	        return new ResponseEntity<>("Passenger updated successfully", HttpStatus.OK);
	    }

	    @DeleteMapping("/delete/{id}")
	    public ResponseEntity<String> deletePassenger(@PathVariable int id) throws UserNotFoundException {
	        passengerService.deletePassenger(id);
	        return new ResponseEntity<>("Passenger deleted successfully", HttpStatus.OK);
	    }
	
	
	
}
