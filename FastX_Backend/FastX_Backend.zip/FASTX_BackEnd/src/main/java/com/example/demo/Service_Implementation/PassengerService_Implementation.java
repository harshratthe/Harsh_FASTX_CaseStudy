package com.example.demo.Service_Implementation;

import java.util.List;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.demo.DTO.PassengerDTO;
import com.example.demo.Entity.Booking;
import com.example.demo.Entity.Passenger;
import com.example.demo.Exceptions.BookingNotFoundException;
import com.example.demo.Exceptions.UserNotFoundException;
import com.example.demo.Mappers.PassengerMapper;
import com.example.demo.Repositories.BookingRepository;
import com.example.demo.Repositories.PassengerRepository;
import com.example.demo.Service.PassengerService;

@Service
public class PassengerService_Implementation implements PassengerService {

	
	@Autowired
    private PassengerRepository passengerRepo;

    @Autowired
    private BookingRepository bookingRepo;
	
	
	@Override
	public void addPassenger(PassengerDTO passengerDto) {
		 Passenger passenger = PassengerMapper.toEntity(passengerDto);
	        passengerRepo.save(passenger);
	        
	}

	@Override
	public PassengerDTO getPassengerById(int id) throws UserNotFoundException {
		 Passenger passenger = passengerRepo.findById(id).orElse(null);
	        if (passenger == null) {
	            throw new UserNotFoundException("Passenger not found with ID: " + id);
	        }
	        return PassengerMapper.toDto(passenger);
	}

	@Override
	public List<PassengerDTO> getPassengersByBookingId(int bookingId) throws BookingNotFoundException {
		Booking booking = bookingRepo.findById(bookingId).orElse(null);
        if (booking == null) {
            throw new BookingNotFoundException("Booking not found with ID: " + bookingId);
        }

        List<Passenger> passengers = passengerRepo.findByBooking_BookingId(bookingId);
        return passengers.stream()
                .map(passenger -> PassengerMapper.toDto(passenger))
                .collect(Collectors.toList());
	}

	@Override
	public void updatePassenger(int id, PassengerDTO passengerDto) throws UserNotFoundException {
		 Passenger existing = passengerRepo.findById(id).orElse(null);
	        if (existing == null) {
	            throw new UserNotFoundException("Passenger not found with ID: " + id);
	        }

	        existing.setPassengerName(passengerDto.getName());
	        existing.setPassengerAge(passengerDto.getAge());
	        existing.setGender(passengerDto.getGender());
	        existing.setBooking(new Booking());
	        existing.getBooking().setBookingId(passengerDto.getBookingId());

	        passengerRepo.save(existing);
		
	}

	@Override
	public void deletePassenger(int id) throws UserNotFoundException {
		  if (!passengerRepo.existsById(id)) {
	            throw new UserNotFoundException("Passenger not found with ID: " + id);
	        }
	        passengerRepo.deleteById(id);
		
	}

}
