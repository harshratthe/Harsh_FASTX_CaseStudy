package com.example.demo.Service_Implementation;

import java.time.LocalDate;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.demo.DTO.BusDTO;
import com.example.demo.Entity.Bus;
import com.example.demo.Entity.Route;
import com.example.demo.Entity.User;
import com.example.demo.Enum.Amenity;
import com.example.demo.Enum.BusType;
import com.example.demo.Exceptions.BusNotFoundException;
import com.example.demo.Exceptions.RouteNotFoundException;
import com.example.demo.Exceptions.UserNotFoundException;
import com.example.demo.Mappers.BusMapper;
import com.example.demo.Repositories.BusRepository;
import com.example.demo.Repositories.RouteRepository;
import com.example.demo.Repositories.UserRepository;
import com.example.demo.Service.BusService;

@Service
public class BusService_Implementation implements BusService {

	 @Autowired
	    private BusRepository busRepo;

	    @Autowired
	    private RouteRepository routeRepo;

	    @Autowired
	    private BusMapper busMapper;

	
	    @Autowired
	    private UserRepository userRepo;
	    
	    
	
	@Override
	public List<BusDTO> getAllBuses() {
		List<Bus> buses = busRepo.findAll();
        return buses.stream()
                .map(bus ->  busMapper.toDto(bus))
                .collect(Collectors.toList());
	}

	@Override
	public BusDTO getBusById(int busId) throws BusNotFoundException {
		 Bus bus = busRepo.findById(busId)
			        .orElseThrow(() -> new BusNotFoundException("Bus not found with ID: " + busId));
			    return busMapper.toDto(bus);
	}

	@Override
	public List<BusDTO> getBusesByRoute(int routeId) {
		 List<Bus> buses = busRepo.findByRoute_RouteId(routeId);
	        return buses.stream()
	                .map(bus ->  busMapper.toDto(bus))
	                .collect(Collectors.toList());
	}
	
	@Override
	public List<BusDTO> searchBusesByRouteAndDate(String origin, String destination, LocalDate date) {
		 List<Bus> buses = busRepo.findByRouteOriginAndRouteDestinationAndDate(origin, destination, date);
		    return buses.stream().map(busMapper::toDto).collect(Collectors.toList());
	}

	@Override
	public List<BusDTO> getBusesByAmenities(List<Amenity> amenities) {
		 List<Bus> buses = busRepo.findAll();

	        return buses.stream()
	                .filter(bus -> bus.getAmenities() != null && bus.getAmenities().containsAll(amenities))
	                .map(bus ->  busMapper.toDto(bus))
	                .collect(Collectors.toList());
	}

	@Override
	public List<BusDTO> searchBusesByTypeAndDate(BusType busType, LocalDate date) {
		 List<Bus> buses = busRepo.findByBusTypeAndDate(busType, date);
	        return buses.stream()
	                .map(bus ->  busMapper.toDto(bus))
	                .collect(Collectors.toList());
	}

	@Override
	public BusDTO addBus(BusDTO busDto) throws RouteNotFoundException, UserNotFoundException {
		Bus bus = busMapper.toEntity(busDto);

	    // Ensure operator is a managed entity
	    if (busDto.getOperator() != null && busDto.getOperator().getUserId() != 0) {
	        User operator = userRepo.findById(busDto.getOperator().getUserId())
	                .orElseThrow(() -> new UserNotFoundException("Operator with ID " + busDto.getOperator().getUserId() + " not found."));
	        bus.setOperator(operator);
	    }

	    // Ensure route is a managed entity
	    if (busDto.getRoute() != null && busDto.getRoute().getRouteId() != 0) {
	        Route route = routeRepo.findById(busDto.getRoute().getRouteId())
	                .orElseThrow(() -> new RouteNotFoundException("Route with ID " + busDto.getRoute().getRouteId() + " not found."));
	        bus.setRoute(route);
	    }

	    // Save the bus
	    Bus savedBus = busRepo.save(bus);

	    // Return DTO
	    return busMapper.toDto(savedBus);
	}

	@Override
	public void deleteBus(int id) throws BusNotFoundException {
		 Bus bus = busRepo.findById(id)
			        .orElseThrow(() -> new BusNotFoundException("Bus with ID " + id + " not found."));
			    busRepo.delete(bus);
		
	}

	@Override
	public BusDTO updateBus(int id, BusDTO busDto) throws UserNotFoundException, RouteNotFoundException, BusNotFoundException {
		Bus existingBus = busRepo.findById(id)
		        .orElseThrow(() -> new BusNotFoundException("Bus with ID " + id + " not found."));

		    // Update basic fields
		    existingBus.setBusNumber(busDto.getBusNumber());
		    existingBus.setBusName(busDto.getBusName());
		    existingBus.setBusType(busDto.getBusType());
		    existingBus.setTotalSeats(busDto.getTotalSeats());
		    existingBus.setAmenities(busDto.getAmenities());
		    existingBus.setBusStatus(busDto.getBusStatus());
		    existingBus.setArrival(busDto.getArrival());
		    existingBus.setDeparture(busDto.getDeparture());
		    existingBus.setPricePerSeat(busDto.getPricePerSeat());
		    existingBus.setDate(busDto.getDate());

		    // Set Route
		    if (busDto.getRoute() != null && busDto.getRoute().getRouteId() != 0) {
		        Route route = routeRepo.findById(busDto.getRoute().getRouteId())
		            .orElseThrow(() -> new RouteNotFoundException("Route with ID " + busDto.getRoute().getRouteId() + " not found."));
		        existingBus.setRoute(route);
		    }

		    // Set Operator
		    if (busDto.getOperator() != null && busDto.getOperator().getUserId() != 0) {
		        User operator = userRepo.findById(busDto.getOperator().getUserId())
		            .orElseThrow(() -> new UserNotFoundException("Operator with ID " + busDto.getOperator().getUserId() + " not found."));
		        existingBus.setOperator(operator);
		    }

		    Bus saved = busRepo.save(existingBus);
		    return busMapper.toDto(saved);
	}

}
