package com.example.demo.Service_Implementation;

import java.util.List;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.demo.DTO.BookingDTO;
import com.example.demo.Entity.Booking;
import com.example.demo.Entity.Bus;
import com.example.demo.Entity.Route;
import com.example.demo.Entity.Seat;
import com.example.demo.Entity.User;
import com.example.demo.Exceptions.BookingNotFoundException;
import com.example.demo.Mappers.BookingMapper;
import com.example.demo.Repositories.BookingRepository;
import com.example.demo.Repositories.BusRepository;
import com.example.demo.Repositories.RouteRepository;
import com.example.demo.Repositories.SeatRepository;
import com.example.demo.Repositories.UserRepository;
import com.example.demo.Service.BookingService;

@Service
public class BookingService_Implementation implements BookingService{

	@Autowired
    private BookingRepository bookingRepo;

    @Autowired
    private SeatRepository seatRepo;

    @Autowired
    private BookingMapper bookingMapper;
	
	
	@Autowired
	private UserRepository userRepo;
	
	@Autowired
	private BusRepository busRepo;
	
	@Autowired
	private RouteRepository routeRepo;
	
	
	@Override
	public BookingDTO bookTicket(BookingDTO bookingDto) {
		 Booking booking = bookingMapper.toEntity(bookingDto);

		    // Manually set related entities using IDs
		    User user = userRepo.findById(bookingDto.getUser().getUserId())
		                .orElseThrow(() -> new RuntimeException("User not found"));
		    Bus bus = busRepo.findById(bookingDto.getBus().getBusId())
		                .orElseThrow(() -> new RuntimeException("Bus not found"));
		    Route route = routeRepo.findById(bookingDto.getRoute().getRouteId())
		                .orElseThrow(() -> new RuntimeException("Route not found"));

		    booking.setUser(user);
		    booking.setBus(bus);
		    booking.setRoute(route);

		    Booking saved = bookingRepo.save(booking);
		    return bookingMapper.toDto(saved);
	}

	@Override
	public List<BookingDTO> getUserBookings(int userId) {
		 List<Booking> bookings = bookingRepo.findByUser_UserId(userId);
	        return bookings.stream()
	                .map(b -> bookingMapper.toDto(b))
	                .collect(Collectors.toList());
	}

	@Override
	public BookingDTO getBookingById(int bookingId) throws BookingNotFoundException {
		 Booking booking = bookingRepo.findById(bookingId).orElse(null);
	        if (booking == null) {
	            throw new BookingNotFoundException("Booking not found with ID: " + bookingId);
	        }
	        return bookingMapper.toDto(booking);
	}

	@Override
	public String cancelBooking(int bookingId) throws BookingNotFoundException {
		Booking booking = bookingRepo.findById(bookingId).orElse(null);
        if (booking == null) {
            throw new BookingNotFoundException("Booking not found with ID: " + bookingId);
        }

        // Free the seats
        List<Seat> seats = booking.getSeats();
        for (Seat seat : seats) {
            seat.setAvailable(true);          // Mark seat as available again
            seat.setBooking(null);            // Remove link between seat and booking
        }
        seatRepo.saveAll(seats);

        bookingRepo.delete(booking);
        return "Booking cancelled successfully";
	}

	@Override
	public List<BookingDTO> getAllBookings() {
		List<Booking> bookings = bookingRepo.findAll();
        return bookings.stream()
                .map(b -> bookingMapper.toDto(b))
                .collect(Collectors.toList());
	}

	@Override
	public List<Booking> getBookingsByOperatorId(int operatorId) {
		 List<Booking> allBookings = bookingRepo.findAll();
		    return allBookings.stream()
		        .filter(b -> b.getBus() != null &&
		                     b.getBus().getOperator() != null &&
		                     b.getBus().getOperator().getUserId() == operatorId)
		        .collect(Collectors.toList());
	}

}
