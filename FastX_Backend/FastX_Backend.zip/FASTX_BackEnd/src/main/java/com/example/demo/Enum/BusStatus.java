package com.example.demo.Enum;

public enum BusStatus {
	ACTIVE, INACTIVE
}
