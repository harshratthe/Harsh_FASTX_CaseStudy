package com.example.demo.Service;

import java.util.List;

import com.example.demo.DTO.SeatDTO;
import com.example.demo.Exceptions.SeatNotFoundException;

public interface SeatService {

	List<SeatDTO> getSeatsByBusId(int busId);

    SeatDTO getSeatById(int seatId) throws SeatNotFoundException;

    void addSeat(SeatDTO seatDto);

    void updateSeat(int seatId, SeatDTO seatDto) throws SeatNotFoundException;

    String deleteSeat(int seatId) throws SeatNotFoundException;
	
	
	
}
