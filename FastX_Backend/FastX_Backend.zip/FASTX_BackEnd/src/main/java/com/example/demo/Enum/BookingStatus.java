package com.example.demo.Enum;

public enum BookingStatus {
	CONFIRMED, CANCELLED
}
