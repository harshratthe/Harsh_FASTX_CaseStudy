package com.example.demo.Exceptions;

import java.time.LocalDateTime;
import java.util.Map;

public class ErrorDetails {

	LocalDateTime time;
	String msg;
	String path;
	Integer errorCode;
	Map<String,String> hashMap;
	public ErrorDetails() {
		super();
		// TODO Auto-generated constructor stub
	}
	public ErrorDetails(LocalDateTime time, String msg, String path, Integer errorCode) {
		super();
		this.time = time;
		this.msg = msg;
		this.path = path;
		this.errorCode = errorCode;
	}
	public LocalDateTime getTime() {
		return time;
	}
	public void setTime(LocalDateTime time) {
		this.time = time;
	}
	public String getMsg() {
		return msg;
	}
	public void setMsg(String msg) {
		this.msg = msg;
	}
	public String getPath() {
		return path;
	}
	public void setPath(String path) {
		this.path = path;
	}
	public Integer getErrorCode() {
		return errorCode;
	}
	public void setErrorCode(Integer errorCode) {
		this.errorCode = errorCode;
	}
	public Map<String, String> getHashMap() {
		return hashMap;
	}
	public void setHashMap(Map<String, String> hashMap) {
		this.hashMap = hashMap;
	}
	@Override
	public String toString() {
		return "ErrorDetails [time=" + time + ", msg=" + msg + ", path=" + path + ", errorCode=" + errorCode + "]";
	}
	
	
	
}
