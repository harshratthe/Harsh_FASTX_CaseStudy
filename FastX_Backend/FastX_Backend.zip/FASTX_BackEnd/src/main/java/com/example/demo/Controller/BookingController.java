package com.example.demo.Controller;

import java.util.List;
import java.util.stream.Collectors;

import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo.DTO.BookingDTO;
import com.example.demo.Entity.Booking;
import com.example.demo.Exceptions.BookingNotFoundException;
import com.example.demo.Service.BookingService;

import jakarta.validation.Valid;

@RestController
@CrossOrigin("http://localhost:3000")
@RequestMapping("/bookings")
public class BookingController {

	 @Autowired
	    private BookingService bookingService;

	 
	 @Autowired
	 private ModelMapper modelMapper;



	 
	 
	 
	    // Book tickets
	

	    @PostMapping("/add")
	    public ResponseEntity<BookingDTO> bookTickets(@Valid @RequestBody BookingDTO bookingDto) {
	        BookingDTO booked = bookingService.bookTicket(bookingDto);
	        HttpHeaders headers = new HttpHeaders();
	        headers.add("info", "Booking created successfully");
	        return new ResponseEntity<>(booked, headers, HttpStatus.CREATED);
	    }

	    // View all bookings by userId
	    @GetMapping("/getbookingbyuserid/{userId}")
	    public ResponseEntity<List<BookingDTO>> getUserBookings(@PathVariable int userId) {
	        List<BookingDTO> bookings = bookingService.getUserBookings(userId);
	        HttpHeaders headers = new HttpHeaders();
	        headers.add("info", "Bookings for user fetched successfully");
	        return new ResponseEntity<>(bookings, headers, HttpStatus.OK);
	    }

	    // Get booking by bookingId
	    @GetMapping("/getbookingbybookingid/{bookingId}")
	    public ResponseEntity<BookingDTO> getBookingById(@PathVariable int bookingId) throws BookingNotFoundException {
	        BookingDTO booking = bookingService.getBookingById(bookingId);
	        HttpHeaders headers = new HttpHeaders();
	        headers.add("info", "Booking details fetched");
	        return new ResponseEntity<>(booking, headers, HttpStatus.OK);
	    }

	    // Cancel booking by bookingId
	    @DeleteMapping("/cancel/{bookingId}")
	    public ResponseEntity<String> cancelBooking(@PathVariable int bookingId) throws BookingNotFoundException {
	        String message = bookingService.cancelBooking(bookingId);
	        HttpHeaders headers = new HttpHeaders();
	        headers.add("info", "Booking cancelled successfully");
	        return new ResponseEntity<>(message, headers, HttpStatus.OK);
	    }

	    // Admin - View all bookings
	    @GetMapping
	    public ResponseEntity<List<BookingDTO>> getAllBookings() {
	        List<BookingDTO> bookings = bookingService.getAllBookings();
	        HttpHeaders headers = new HttpHeaders();
	        headers.add("info", "All bookings fetched");
	        return new ResponseEntity<>(bookings, headers, HttpStatus.OK);
	    }
	
	    @GetMapping("/getbyoperator/{operatorId}")
	    public ResponseEntity<List<BookingDTO>> getBookingsByOperator(@PathVariable int operatorId) {
	        List<Booking> bookings = bookingService.getBookingsByOperatorId(operatorId);
	        List<BookingDTO> bookingDTOs = bookings.stream()
	            .map(b -> modelMapper.map(b, BookingDTO.class))
	            .collect(Collectors.toList());
	        return ResponseEntity.ok(bookingDTOs);
	    }


	    
	    
	    
	    
	    
	    
	    
}
