package com.example.demo.Enum;

public enum UserRole {
	 PASSENGER, OPERATOR, ADMIN
}
