package com.example.demo.Enum;

public enum Amenity {
	 WIFI,
	    AC,
	    NON_AC,
	    CHARGING_PORT,
	    WATER_BOTTLE,
	    BLANKET,
	    RECLINER_SEAT,
	    TV,
	    SNACKS
}
