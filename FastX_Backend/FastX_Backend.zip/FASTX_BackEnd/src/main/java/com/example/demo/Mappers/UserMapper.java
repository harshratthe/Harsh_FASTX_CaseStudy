package com.example.demo.Mappers;

import org.springframework.stereotype.Component;

import com.example.demo.DTO.UserDTO;
import com.example.demo.Entity.User;

@Component
public class UserMapper {
 
	 public static UserDTO toDTO(User user) {
	        if (user == null) return null;

	        UserDTO dto = new UserDTO();
	        dto.setUserId(user.getUserId());
	        dto.setUserName(user.getUserName()); 
	        dto.setEmail(user.getEmail());
	        dto.setPassword(user.getPassword());
	        dto.setPhone(user.getPhone()); 
	        dto.setAddress(user.getAddress());
	        dto.setRole(user.getRole());
	        return dto;
	    }

	    public static User toEntity(UserDTO dto) {
	        if (dto == null) return null;

	        User user = new User();
	        user.setUserId(dto.getUserId());
	        user.setUserName(dto.getUserName());    
	        user.setEmail(dto.getEmail());
	        user.setPassword(dto.getPassword());
	        user.setPhone(dto.getPhone());    
	        user.setAddress(dto.getAddress());
	        user.setRole(dto.getRole());
	        return user;
	    }
	
	
	
}
