package com.example.demo.Controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo.DTO.PaymentDTO;
import com.example.demo.Exceptions.BookingNotFoundException;
import com.example.demo.Exceptions.PaymentNotFoundException;
import com.example.demo.Exceptions.UserNotFoundException;
import com.example.demo.Service.PaymentService;

@RestController
@CrossOrigin("http://localhost:3000")
@RequestMapping("/payments")
public class PaymentController {

	 @Autowired
	    private PaymentService paymentService;

	    // Add a new payment
	 @PreAuthorize("hasRole('PASSENGER')")

	    @PostMapping("/add")
	    public ResponseEntity<String> makePayment(@RequestBody PaymentDTO paymentDto) throws BookingNotFoundException, UserNotFoundException {
	        paymentService.makePayment(paymentDto);
	        return new ResponseEntity<>("Payment processed", HttpStatus.OK);
	    }

	    // Get payment by ID
	    @GetMapping("/{id}")
	    public ResponseEntity<PaymentDTO> getPaymentById(@PathVariable int id) throws PaymentNotFoundException {
	        PaymentDTO dto = paymentService.getPaymentById(id);
	        return new ResponseEntity<>(dto, HttpStatus.OK);
	    }

	    // Get all payments
	    @GetMapping
	    public ResponseEntity<List<PaymentDTO>> getAllPayments() {
	        List<PaymentDTO> payments = paymentService.getAllPayments();
	        return new ResponseEntity<>(payments, HttpStatus.OK);
	    }

	    // Get payments by user ID
	    @GetMapping("/user/{userId}")
	    public ResponseEntity<List<PaymentDTO>> getPaymentsByUserId(@PathVariable int userId) {
	        List<PaymentDTO> payments = paymentService.getPaymentsByUserId(userId);
	        return new ResponseEntity<>(payments, HttpStatus.OK);
	    }

	    // Update payment
	    @PutMapping("/{id}")
	    public ResponseEntity<String> updatePayment(@PathVariable int id, @RequestBody PaymentDTO dto) throws PaymentNotFoundException {
	        paymentService.updatePayment(id, dto);
	        return new ResponseEntity<>("Payment updated", HttpStatus.OK);
	    }

	    // Refund a payment (optional use-case)
	    @PutMapping("/refund/{id}")
	    public ResponseEntity<String> refundPayment(@PathVariable int id) throws PaymentNotFoundException {
	        paymentService.refundPayment(id);
	        return new ResponseEntity<>("Payment refunded", HttpStatus.OK);
	    }
	
	
	
}
