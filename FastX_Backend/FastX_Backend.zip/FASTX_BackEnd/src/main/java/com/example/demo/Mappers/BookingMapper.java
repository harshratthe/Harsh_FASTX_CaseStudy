package com.example.demo.Mappers;



import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.example.demo.DTO.BookingDTO;


import com.example.demo.Entity.Booking;
import com.example.demo.Entity.Bus;
import com.example.demo.Entity.Route;
import com.example.demo.Entity.User;




@Component
public class BookingMapper {
	
	@Autowired
	private UserMapper userMapper;

	@Autowired
	private RouteMapper routeMapper;

	@Autowired
	private BusMapper busMapper;
	
	@Autowired
	private SeatMapper seatMapper;

	
	 public  BookingDTO toDto(Booking booking) {
		 if (booking == null) return null;

	        BookingDTO dto = new BookingDTO();
	        dto.setBookingId(booking.getBookingId());
	        dto.setBookingDate(booking.getBookingDate());
	        dto.setTotalAmount(booking.getTotalAmount());
	        dto.setBookingStatus(booking.getBookingStatus());

	        // Map only IDs to avoid .toDto() errors
	        if (booking.getUser() != null) {
	            dto.setUserId(booking.getUser().getUserId());
	            dto.setUser(userMapper.toDTO(booking.getUser()));
	        }

	        if (booking.getRoute() != null) {
	            dto.setRouteId(booking.getRoute().getRouteId());
	            dto.setRoute(routeMapper.toDTO(booking.getRoute()));
	        }

	        if (booking.getBus() != null) {
	            dto.setBusId(booking.getBus().getBusId());
	            dto.setBus(busMapper.toDto(booking.getBus()));
	        }
	        
	        if (booking.getSeats() != null) {
	            dto.setSeats(
	                booking.getSeats()
	                       .stream()
	                       .map(seatMapper::toDto)
	                       .collect(Collectors.toList())
	            );
	        }

	        

	        return dto;
	    }

	    public Booking toEntity(BookingDTO dto) {
	        if (dto == null) return null;

	        Booking booking = new Booking();
	        booking.setBookingId(dto.getBookingId());
	        booking.setBookingDate(dto.getBookingDate());
	        booking.setTotalAmount(dto.getTotalAmount());
	        booking.setBookingStatus(dto.getBookingStatus());

	        // Optionally reconstruct only by ID if needed in service layer
	        if (dto.getUserId() != 0) {
	            User user = new User();
	            user.setUserId(dto.getUserId());
	            booking.setUser(user);
	        }

	        if (dto.getRouteId() != 0) {
	            Route route = new Route();
	            route.setRouteId(dto.getRouteId());
	            booking.setRoute(route);
	        }

	        if (dto.getBusId() != 0) {
	            Bus bus = new Bus();
	            bus.setBusId(dto.getBusId());
	            booking.setBus(bus);
	        }

	        return booking;
	    }

}
