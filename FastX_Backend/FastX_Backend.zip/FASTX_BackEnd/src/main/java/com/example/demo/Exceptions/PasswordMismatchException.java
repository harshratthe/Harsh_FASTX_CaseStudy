package com.example.demo.Exceptions;

public class PasswordMismatchException  extends Exception {


    public PasswordMismatchException(String message) {
        super(message);
    }
	
}
