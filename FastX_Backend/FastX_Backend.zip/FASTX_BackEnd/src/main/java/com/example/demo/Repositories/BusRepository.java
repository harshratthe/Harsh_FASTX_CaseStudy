package com.example.demo.Repositories;

import java.time.LocalDate;
import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.example.demo.Entity.Bus;
import com.example.demo.Enum.BusType;

@Repository
public interface BusRepository extends JpaRepository<Bus, Integer> {

    List<Bus> findByRoute_RouteId(int routeId);  // to get buses by routeId

   
    
 // In BusRepository.java
    List<Bus> findByRouteOriginAndRouteDestinationAndDate(String origin, String destination, LocalDate date);

    List<Bus> findByBusTypeAndDate(BusType busType, LocalDate date);
	

}
