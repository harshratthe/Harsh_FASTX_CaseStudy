package com.example.demo.Service;

import java.time.LocalDate;
import java.util.List;

import com.example.demo.DTO.BusDTO;
import com.example.demo.Enum.Amenity;
import com.example.demo.Enum.BusType;
import com.example.demo.Exceptions.BusNotFoundException;
import com.example.demo.Exceptions.RouteNotFoundException;
import com.example.demo.Exceptions.UserNotFoundException;

public interface BusService {

	
    BusDTO addBus(BusDTO busDto) throws RouteNotFoundException, UserNotFoundException;

	
	List<BusDTO> getAllBuses();

    BusDTO getBusById(int busId) throws BusNotFoundException, BusNotFoundException;

    List<BusDTO> getBusesByRoute(int routeId);

    List<BusDTO> searchBusesByRouteAndDate(String origin, String destination, LocalDate date);


    List<BusDTO> getBusesByAmenities(List<Amenity> amenities);

    List<BusDTO> searchBusesByTypeAndDate(BusType busType, LocalDate date);
	
    void deleteBus(int id) throws BusNotFoundException;

    BusDTO updateBus(int id, BusDTO busDto) throws UserNotFoundException, RouteNotFoundException, BusNotFoundException;
    
    
    
    

}
