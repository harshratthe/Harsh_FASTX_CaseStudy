package com.example.demo.Exceptions;

public class SeatNotFoundException extends RuntimeException {

	public SeatNotFoundException(String message) {
        super(message);
    }
	
	
}
