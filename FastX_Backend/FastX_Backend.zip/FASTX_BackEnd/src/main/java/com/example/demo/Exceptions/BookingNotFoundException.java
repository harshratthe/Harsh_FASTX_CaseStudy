package com.example.demo.Exceptions;

public class BookingNotFoundException extends Exception{

	 public BookingNotFoundException(String message) {
	        super(message);
	    }
	
	
	
}
