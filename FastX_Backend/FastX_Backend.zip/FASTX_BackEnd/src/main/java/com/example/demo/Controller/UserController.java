	package com.example.demo.Controller;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.userdetails.User;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;


import com.example.demo.DTO.UserDTO;
import com.example.demo.Enum.UserRole;
import com.example.demo.Exceptions.EmailAlreadyExistsException;
import com.example.demo.Exceptions.InvalidCredentialsException;
import com.example.demo.Exceptions.UserNotFoundException;
import com.example.demo.Repositories.UserRepository;
import com.example.demo.Service.UserService;
import com.example.demo.config.CustomUserDetailsService;
import com.example.demo.util.JwtUtil;

import jakarta.validation.Valid;


@RestController
@CrossOrigin("http://localhost:3000")
@RequestMapping("/users")
public class UserController {
       
	@Autowired
    private UserService userService;
	
	@Autowired
    private JwtUtil jwtUtil;

    @Autowired
    private PasswordEncoder passwordEncoder;

    @Autowired
    private CustomUserDetailsService customUserDetailsService;
	
   
    @Autowired
    private UserRepository userRepo;

    // Register user 
    @PostMapping("/register")
    public ResponseEntity<UserDTO> registerUser(@Valid @RequestBody UserDTO userDto)  // @Valid Tells Spring to validate the userDto fields (e.g., not null, email format, etc.).
            throws EmailAlreadyExistsException {                                   // @RequestBody UserDTO userDto: Takes the JSON body of the request and maps it to a UserDTO object.
        UserDTO saved = userService.registerUser(userDto);
        HttpHeaders headers = new HttpHeaders();
        headers.add("info", "User registered successfully");
        return new ResponseEntity<>(saved, headers, HttpStatus.CREATED);
    }

   
    @PostMapping("/login")
    public ResponseEntity<Map<String, Object>> loginUser(@RequestBody UserDTO userDto)
            throws UserNotFoundException, InvalidCredentialsException {

        UserDTO response = userService.login(userDto.getEmail(), userDto.getPassword());

        // 🔍 Get actual User entity from DB
        com.example.demo.Entity.User user = userRepo.findByEmail(response.getEmail());

        String token = jwtUtil.generateToken(user);

        Map<String, Object> result = new HashMap<>();
        result.put("token", token);
        result.put("user", response);
        result.put("message", "Login successful");

        return ResponseEntity.ok(result);
    }

    @PostMapping("/login/admin")
    public ResponseEntity<Map<String, Object>> loginAdmin(@RequestBody UserDTO userDto)
            throws UserNotFoundException, InvalidCredentialsException {

        UserDTO response = userService.loginAdmin(userDto.getEmail(), userDto.getPassword());

        com.example.demo.Entity.User user = userRepo.findByEmail(response.getEmail());

        String token = jwtUtil.generateToken(user);

        Map<String, Object> result = new HashMap<>();
        result.put("token", token);
        result.put("user", response);
        result.put("message", "Admin login successful");

        return ResponseEntity.ok(result);
    }

    @PostMapping("/login/operator")
    public ResponseEntity<Map<String, Object>> loginOperator(@RequestBody UserDTO userDto)
            throws UserNotFoundException, InvalidCredentialsException {

        UserDTO response = userService.loginOperator(userDto.getEmail(), userDto.getPassword());

        com.example.demo.Entity.User user = userRepo.findByEmail(response.getEmail());

        String token = jwtUtil.generateToken(user);

        Map<String, Object> result = new HashMap<>();
        result.put("token", token);
        result.put("user", response);
        result.put("message", "Operator login successful");

        return ResponseEntity.ok(result);
    }

    // Forgot password
    @PostMapping("/forgot-password")
    public ResponseEntity<String> forgotPassword(@RequestParam String email)
            throws UserNotFoundException {
        String result = userService.forgotPassword(email);
        HttpHeaders headers = new HttpHeaders();
        headers.add("info", "Password recovery email sent (if registered)");
        return new ResponseEntity<>(result, headers, HttpStatus.OK);
    }

    // Update user
    @PutMapping("/update/{id}")
    public ResponseEntity<UserDTO> updateUser(@PathVariable int id, @RequestBody UserDTO userDto)
            throws UserNotFoundException {
        UserDTO updated = userService.updateUser(id, userDto);
        HttpHeaders headers = new HttpHeaders();
        headers.add("info", "User updated successfully");
        return new ResponseEntity<>(updated, headers, HttpStatus.OK);
    }

    // Delete user
    @DeleteMapping("/delete/{id}")
    public ResponseEntity<String> deleteUser(@PathVariable int id) throws UserNotFoundException {
    	try {
            String result = userService.deleteUser(id);
            HttpHeaders headers = new HttpHeaders();
            headers.add("info", "User deleted successfully");
            return new ResponseEntity<>(result, headers, HttpStatus.NO_CONTENT);
        } catch (IllegalStateException e) {
            return ResponseEntity.status(HttpStatus.CONFLICT).body(e.getMessage());
        }
    }

    // Get user by ID
    @GetMapping("/{id}")
    public ResponseEntity<UserDTO> getUserById(@PathVariable int id) throws UserNotFoundException {
        UserDTO dto = userService.getUserById(id);
        HttpHeaders headers = new HttpHeaders();
        headers.add("info", "User data fetched successfully");
        return new ResponseEntity<>(dto, headers, HttpStatus.OK);
    }

    // Get users by role (ADMIN, OPERATOR, PASSENGER)
    @GetMapping("/role/{role}")
    public ResponseEntity<List<UserDTO>> getUsersByRole(@PathVariable UserRole role) {
        List<UserDTO> users = userService.getUsersByRole(role);
        HttpHeaders headers = new HttpHeaders();
        headers.add("info", "Users fetched by role");
        return new ResponseEntity<>(users, headers, HttpStatus.OK);
    }

    // View current user profile
    @GetMapping("/profile")
    public ResponseEntity<UserDTO> getProfile(@RequestParam int userId) throws UserNotFoundException {
        UserDTO profile = userService.getUserById(userId);
        HttpHeaders headers = new HttpHeaders();
        headers.add("info", "User profile data retrieved");
        return new ResponseEntity<>(profile, headers, HttpStatus.OK);
    }

    // ADMIN: Get all users
    @GetMapping("/all")
    public ResponseEntity<List<UserDTO>> getAllUsers() {
        List<UserDTO> users = userService.getAllUsers();
        HttpHeaders headers = new HttpHeaders();
        headers.add("info", "All users fetched");
        return new ResponseEntity<>(users, headers, HttpStatus.OK);
    }

    // ADMIN: Get all bus operators
    @GetMapping("/operators")
    public ResponseEntity<List<UserDTO>> getAllOperators() {
        List<UserDTO> operators = userService.getAllOperators();
        HttpHeaders headers = new HttpHeaders();
        headers.add("info", "All bus operators fetched");
        return new ResponseEntity<>(operators, headers, HttpStatus.OK);
    }

    // ADMIN: Delete a bus operator
    @DeleteMapping("/operators/{id}")
    public ResponseEntity<String> deleteOperator(@PathVariable int id) throws UserNotFoundException {
        String result = userService.deleteOperator(id);
        HttpHeaders headers = new HttpHeaders();
        headers.add("info", "Bus operator deleted");
        return new ResponseEntity<>(result, headers, HttpStatus.OK);
    }
	
	
	
}
