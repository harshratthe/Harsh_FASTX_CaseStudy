package com.example.demo.Enum;

public enum BusType {
	 AC_SEATER, NON_AC_SEATER, AC_SLEEPER, NON_AC_SLEEPER
}
