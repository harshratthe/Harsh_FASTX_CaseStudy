package com.example.demo.Service_Implementation;

import java.util.List;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.demo.DTO.SeatDTO;
import com.example.demo.Entity.Seat;
import com.example.demo.Exceptions.SeatNotFoundException;
import com.example.demo.Mappers.SeatMapper;

import com.example.demo.Repositories.SeatRepository;

import com.example.demo.Service.SeatService;

@Service
public class SeatService_Implementation implements SeatService {

	@Autowired
    private SeatRepository seatRepo;

   

    @Autowired
    private SeatMapper seatMapper;
	
	
	
	
	@Override
	public List<SeatDTO> getSeatsByBusId(int busId) {
		List<Seat> seats = seatRepo.findByBus_BusId(busId);
        return seats.stream()
                .map(seat -> seatMapper.toDto(seat))
                .collect(Collectors.toList());
	}

	@Override
	public SeatDTO getSeatById(int seatId) throws SeatNotFoundException {
		Seat seat = seatRepo.findById(seatId).orElse(null);
        if (seat == null) {
            throw new SeatNotFoundException("Seat not found with ID: " + seatId);
        }
        return seatMapper.toDto(seat);
	}

	@Override
	public void addSeat(SeatDTO seatDto) {
		Seat seat = seatMapper.toEntity(seatDto);
        seatRepo.save(seat);
		
	}

	@Override
	public void updateSeat(int seatId, SeatDTO seatDto) throws SeatNotFoundException {
		Seat existing = seatRepo.findById(seatId).orElse(null);
        if (existing == null) {
            throw new SeatNotFoundException("Seat not found with ID: " + seatId);
        }

        existing.setSeatNumber(seatDto.getSeatNumber());
        existing.setAvailable(seatDto.isAvailable());
        // optionally set booking or bus, if needed in the future

        seatRepo.save(existing);
	}

	@Override
	public String deleteSeat(int seatId) throws SeatNotFoundException {
		  if (!seatRepo.existsById(seatId)) {
	            throw new SeatNotFoundException("Seat not found with ID: " + seatId);
	        }
	        seatRepo.deleteById(seatId);
	        return "Seat deleted successfully";
	}

}
