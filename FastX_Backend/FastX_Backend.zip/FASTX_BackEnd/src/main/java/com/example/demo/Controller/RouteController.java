package com.example.demo.Controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo.DTO.RouteDTO;
import com.example.demo.Exceptions.RouteNotFoundException;
import com.example.demo.Service.RouteService;

import jakarta.validation.Valid;
@RestController
@CrossOrigin("http://localhost:3000")
@RequestMapping("/routes")
public class RouteController {

	
	 @Autowired
	    private RouteService routeService;

	    // Create a new route
	    @PostMapping("/create")
	    public ResponseEntity<String> createRoute(@Valid @RequestBody RouteDTO routeDto) {
	        String result = routeService.createRoute(routeDto);
	        HttpHeaders headers = new HttpHeaders();
	        headers.add("info", "Route creation processed");
	        return new ResponseEntity<>(result, headers, HttpStatus.CREATED);
	    }

	    // Get all routes
	    @GetMapping("/all")
	    public ResponseEntity<List<RouteDTO>> getAllRoutes() {
	        List<RouteDTO> routes = routeService.getAllRoutes();
	        HttpHeaders headers = new HttpHeaders();
	        headers.add("info", "Fetched all routes");
	        return new ResponseEntity<>(routes, headers, HttpStatus.OK);
	    }

	    // Get a single route by ID
	    @GetMapping("/{id}")
	    public ResponseEntity<RouteDTO> getRouteById(@PathVariable int id) throws RouteNotFoundException {
	        RouteDTO route = routeService.getRouteById(id);
	        HttpHeaders headers = new HttpHeaders();
	        headers.add("info", "Fetched route by ID");
	        return new ResponseEntity<>(route, headers, HttpStatus.OK);
	    }

	    // Update route by ID
	    @PutMapping("/update/{id}")
	    public ResponseEntity<String> updateRoute(@PathVariable int id, @RequestBody RouteDTO routeDto) throws RouteNotFoundException {
	        String result = routeService.updateRoute(id, routeDto);
	        HttpHeaders headers = new HttpHeaders();
	        headers.add("info", "Route update processed");
	        return new ResponseEntity<>(result, headers, HttpStatus.OK);
	    }

	    // Delete route by ID
	    @DeleteMapping("/delete/{id}")
	    public ResponseEntity<String> deleteRoute(@PathVariable int id) throws RouteNotFoundException {
	        String result = routeService.deleteRoute(id);
	        HttpHeaders headers = new HttpHeaders();
	        headers.add("info", "Route deletion processed");
	        return new ResponseEntity<>(result, headers, HttpStatus.OK);
	    }
}
