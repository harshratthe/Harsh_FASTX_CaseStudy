package com.example.demo.Controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo.DTO.SeatDTO;
import com.example.demo.Exceptions.SeatNotFoundException;
import com.example.demo.Service.SeatService;

import jakarta.validation.Valid;

@RestController
@CrossOrigin("http://localhost:3000")
@RequestMapping("/seats")
public class SeatController {

	@Autowired
    private SeatService seatService;

    // Get all seats for a given bus
    @GetMapping("/bus/{busId}")
    public ResponseEntity<List<SeatDTO>> getSeatsByBusId(@PathVariable int busId) {
        List<SeatDTO> seats = seatService.getSeatsByBusId(busId);
        HttpHeaders headers = new HttpHeaders();
        headers.add("info", "All seats for bus ID: " + busId);
        return new ResponseEntity<>(seats, headers, HttpStatus.OK);
    }

    // Get a seat by its ID
    @GetMapping("/{seatId}")
    public ResponseEntity<SeatDTO> getSeatById(@PathVariable int seatId) throws SeatNotFoundException {
        SeatDTO seat = seatService.getSeatById(seatId);
        HttpHeaders headers = new HttpHeaders();
        headers.add("info", "Seat details fetched successfully");
        return new ResponseEntity<>(seat, headers, HttpStatus.OK);
    }

    // Add a new seat
    @PostMapping("/add")
    public ResponseEntity<String> addSeat(@Valid @RequestBody SeatDTO seatDto) {
        seatService.addSeat(seatDto);
        HttpHeaders headers = new HttpHeaders();
        headers.add("info", "Seat added successfully");
        return new ResponseEntity<>("Seat added successfully", headers, HttpStatus.CREATED);
    }

    // Update an existing seat
    @PutMapping("/update/{seatId}")
    public ResponseEntity<String> updateSeat(@PathVariable int seatId, @Valid @RequestBody SeatDTO seatDto)
            throws SeatNotFoundException {
        seatService.updateSeat(seatId, seatDto);
        HttpHeaders headers = new HttpHeaders();
        headers.add("info", "Seat updated successfully");
        return new ResponseEntity<>("Seat updated successfully", headers, HttpStatus.OK);
    }

    // Delete a seat by ID
    @DeleteMapping("/delete/{seatId}")
    public ResponseEntity<String> deleteSeat(@PathVariable int seatId) throws SeatNotFoundException {
        String result = seatService.deleteSeat(seatId);
        HttpHeaders headers = new HttpHeaders();
        headers.add("info", "Seat deleted successfully");
        return new ResponseEntity<>(result, headers, HttpStatus.OK);
    }
	
	
	
}
