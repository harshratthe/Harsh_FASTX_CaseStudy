package com.example.demo.Mappers;

import org.springframework.stereotype.Component;

import com.example.demo.DTO.PaymentDTO;
import com.example.demo.Entity.Booking;
import com.example.demo.Entity.Payment;
import com.example.demo.Entity.User;

@Component
public class PaymentMapper {

    public static PaymentDTO toDto(Payment payment) {
        if (payment == null) return null;

        PaymentDTO dto = new PaymentDTO();
        dto.setPaymentId(payment.getPaymentId());
        dto.setAmount(payment.getAmount());
        dto.setPaymentMode(payment.getPaymentMode());
        dto.setTransactionId(payment.getTransactionId());
        dto.setPaymentDate(payment.getPaymentDate());
        dto.setPaymentStatus(payment.getPaymentStatus());

        // Set Booking ID
        if (payment.getBooking() != null) {
            dto.setBookingId(payment.getBooking().getBookingId());

            // Extract user from booking
            User user = payment.getBooking().getUser();
            if (user != null) {
                dto.setUser(UserMapper.toDTO(user));
            }
        }

        return dto;
    }

    public static Payment toEntity(PaymentDTO dto) {
    	 if (dto == null) return null;

    	    Payment payment = new Payment();
    	    payment.setPaymentId(dto.getPaymentId());
    	    payment.setAmount(dto.getAmount());
    	    payment.setPaymentMode(dto.getPaymentMode());
    	    payment.setTransactionId(dto.getTransactionId());
    	    payment.setPaymentDate(dto.getPaymentDate());
    	    payment.setPaymentStatus(dto.getPaymentStatus());

    	    // Set booking with ID (only as reference, actual fetch should happen in Service)
    	    if (dto.getBookingId() != 0) {
    	        Booking booking = new Booking();
    	        booking.setBookingId(dto.getBookingId());
    	        payment.setBooking(booking);
    	    }

    	    // Set user ONLY if needed (your Payment entity has a User field directly)
    	    if (dto.getUser() != null) {
    	        User user = new User();
    	        user.setUserId(dto.getUser().getUserId());
    	        payment.setUser(user);  // Optional depending on entity design
    	    }

    	    return payment;
    }
}
