package com.example.demo.Enum;

public enum PaymentStatus {
	SUCCESS, FAILED, REFUNDED
}
