package com.example.demo.Service;

import java.util.List;

import com.example.demo.DTO.RouteDTO;
import com.example.demo.Exceptions.RouteNotFoundException;

public interface RouteService {

	
	 String createRoute(RouteDTO routeDto);

	    List<RouteDTO> getAllRoutes();

	    RouteDTO getRouteById(int id) throws RouteNotFoundException, RouteNotFoundException;

	    String updateRoute(int id, RouteDTO routeDto) throws RouteNotFoundException;

	    String deleteRoute(int id) throws RouteNotFoundException;
	
	
	
	
}
