package com.example.demo.Service;

import java.util.List;

import com.example.demo.DTO.PaymentDTO;
import com.example.demo.Exceptions.BookingNotFoundException;
import com.example.demo.Exceptions.PaymentNotFoundException;
import com.example.demo.Exceptions.UserNotFoundException;

public interface PaymentService {

	 void makePayment(PaymentDTO paymentDto) throws BookingNotFoundException, UserNotFoundException;

	    PaymentDTO getPaymentById(int paymentId) throws PaymentNotFoundException, PaymentNotFoundException;

	    List<PaymentDTO> getAllPayments();

	    List<PaymentDTO> getPaymentsByUserId(int userId);

	    void updatePayment(int paymentId, PaymentDTO paymentDto) throws PaymentNotFoundException;

	    void refundPayment(int paymentId) throws PaymentNotFoundException;
	
	
	
}
