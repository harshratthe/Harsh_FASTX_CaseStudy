package com.example.demo.DTO;

import java.time.LocalDate;
import java.util.List;

import com.example.demo.Enum.BookingStatus;

import jakarta.validation.constraints.FutureOrPresent;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Positive;


public class BookingDTO {
   
	private int bookingId;

    @NotNull(message = "Booking date is required")
    @FutureOrPresent(message = "Booking date cannot be in the past")
    private LocalDate bookingDate;

    @Positive(message = "Total amount must be positive")
    private double totalAmount;

    @NotNull(message = "Booking status is required")
    private BookingStatus bookingStatus;

    @NotNull(message = "User is required")
    private UserDTO user;

    @NotNull(message = "Route is required")
    private RouteDTO route;

    @NotNull(message = "Bus is required")
    private BusDTO bus;

    private PaymentDTO payment;

    private List<PassengerDTO> passengers;

    private List<SeatDTO> seats;

    private int userId;
    private int routeId;
    private int busId;
	public BookingDTO() {
		super();
		// TODO Auto-generated constructor stub
	}
	public BookingDTO(int bookingId,
			@NotNull(message = "Booking date is required") @FutureOrPresent(message = "Booking date cannot be in the past") LocalDate bookingDate,
			@Positive(message = "Total amount must be positive") double totalAmount,
			@NotNull(message = "Booking status is required") BookingStatus bookingStatus,
			@NotNull(message = "User is required") UserDTO user, @NotNull(message = "Route is required") RouteDTO route,
			@NotNull(message = "Bus is required") BusDTO bus, PaymentDTO payment, List<PassengerDTO> passengers,
			List<SeatDTO> seats, int userId, int routeId, int busId) {
		super();
		this.bookingId = bookingId;
		this.bookingDate = bookingDate;
		this.totalAmount = totalAmount;
		this.bookingStatus = bookingStatus;
		this.user = user;
		this.route = route;
		this.bus = bus;
		this.payment = payment;
		this.passengers = passengers;
		this.seats = seats;
		this.userId = userId;
		this.routeId = routeId;
		this.busId = busId;
	}
	public int getBookingId() {
		return bookingId;
	}
	public void setBookingId(int bookingId) {
		this.bookingId = bookingId;
	}
	public LocalDate getBookingDate() {
		return bookingDate;
	}
	public void setBookingDate(LocalDate bookingDate) {
		this.bookingDate = bookingDate;
	}
	public double getTotalAmount() {
		return totalAmount;
	}
	public void setTotalAmount(double totalAmount) {
		this.totalAmount = totalAmount;
	}
	public BookingStatus getBookingStatus() {
		return bookingStatus;
	}
	public void setBookingStatus(BookingStatus bookingStatus) {
		this.bookingStatus = bookingStatus;
	}
	public UserDTO getUser() {
		return user;
	}
	public void setUser(UserDTO user) {
		this.user = user;
	}
	public RouteDTO getRoute() {
		return route;
	}
	public void setRoute(RouteDTO route) {
		this.route = route;
	}
	public BusDTO getBus() {
		return bus;
	}
	public void setBus(BusDTO bus) {
		this.bus = bus;
	}
	public PaymentDTO getPayment() {
		return payment;
	}
	public void setPayment(PaymentDTO payment) {
		this.payment = payment;
	}
	public List<PassengerDTO> getPassengers() {
		return passengers;
	}
	public void setPassengers(List<PassengerDTO> passengers) {
		this.passengers = passengers;
	}
	public List<SeatDTO> getSeats() {
		return seats;
	}
	public void setSeats(List<SeatDTO> seats) {
		this.seats = seats;
	}
	public int getUserId() {
		return userId;
	}
	public void setUserId(int userId) {
		this.userId = userId;
	}
	public int getRouteId() {
		return routeId;
	}
	public void setRouteId(int routeId) {
		this.routeId = routeId;
	}
	public int getBusId() {
		return busId;
	}
	public void setBusId(int busId) {
		this.busId = busId;
	}
	@Override
	public String toString() {
		return "BookingDTO [bookingId=" + bookingId + ", bookingDate=" + bookingDate + ", totalAmount=" + totalAmount
				+ ", bookingStatus=" + bookingStatus + ", user=" + user + ", route=" + route + ", bus=" + bus
				+ ", payment=" + payment + ", passengers=" + passengers + ", seats=" + seats + ", userId=" + userId
				+ ", routeId=" + routeId + ", busId=" + busId + "]";
	}
    
    
    
    
    
    
    
}
