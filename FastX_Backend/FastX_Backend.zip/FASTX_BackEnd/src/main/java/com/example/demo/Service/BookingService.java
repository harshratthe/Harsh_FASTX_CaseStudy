package com.example.demo.Service;

import java.util.List;

import com.example.demo.DTO.BookingDTO;
import com.example.demo.Entity.Booking;
import com.example.demo.Exceptions.BookingNotFoundException;

public interface BookingService {

	 BookingDTO bookTicket(BookingDTO bookingDto);

	    List<BookingDTO> getUserBookings(int userId);

	    BookingDTO getBookingById(int bookingId) throws BookingNotFoundException;

	    String cancelBooking(int bookingId) throws BookingNotFoundException, BookingNotFoundException;

	    List<BookingDTO> getAllBookings();
	
	    
	    List<Booking> getBookingsByOperatorId(int operatorId);

	
}
