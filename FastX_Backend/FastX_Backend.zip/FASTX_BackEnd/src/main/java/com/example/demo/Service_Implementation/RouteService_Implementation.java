package com.example.demo.Service_Implementation;

import java.util.List;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.demo.DTO.RouteDTO;
import com.example.demo.Entity.Route;
import com.example.demo.Exceptions.RouteNotFoundException;
import com.example.demo.Mappers.RouteMapper;
import com.example.demo.Repositories.RouteRepository;

import com.example.demo.Service.RouteService;

@Service
public class RouteService_Implementation implements RouteService
{

	 @Autowired
	    private RouteRepository RouteRepo;

	    @Autowired
	    private RouteMapper RouteMapper;

	 @Override
	 public String createRoute(RouteDTO routeDto) {
		 Route route = RouteMapper.toEntity(routeDto);
	        RouteRepo.save(route);
	        return "Route created successfully";
	 }

	 @Override
	 public List<RouteDTO> getAllRoutes() {
		 List<Route> routes = RouteRepo.findAll();
	        return routes.stream()
	                .map(route -> RouteMapper.toDTO(route))
	                .collect(Collectors.toList());
	 }

	 @Override
	 public RouteDTO getRouteById(int id) throws RouteNotFoundException {
		 Route route = RouteRepo.findById(id).orElse(null);
	        if (route == null) {
	            throw new RouteNotFoundException("Route not found with ID: " + id);
	        }
	        return RouteMapper.toDTO(route);
	 }

	 @Override
	 public String updateRoute(int id, RouteDTO routeDto) throws RouteNotFoundException {
		 Route existing = RouteRepo.findById(id).orElse(null);
	        if (existing == null) {
	            throw new RouteNotFoundException("Route not found with ID: " + id);
	        }

	        existing.setOrigin(routeDto.getOrigin());
	        existing.setDestination(routeDto.getDestination());
	        existing.setFare(routeDto.getFare());
	        existing.setDistance(routeDto.getDistance());

	        RouteRepo.save(existing);
	        return "Route updated successfully";
	 }

	 @Override
	 public String deleteRoute(int id) throws RouteNotFoundException {
		 Route route = RouteRepo.findById(id).orElse(null);
	        if (route == null) {
	            throw new RouteNotFoundException("Route not found with ID: " + id);
	        }
	        RouteRepo.delete(route);
	        return "Route deleted successfully";
	 }

	
	
}
