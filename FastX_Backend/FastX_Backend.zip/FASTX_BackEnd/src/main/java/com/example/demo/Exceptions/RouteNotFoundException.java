package com.example.demo.Exceptions;

public class RouteNotFoundException extends Exception {

	public  RouteNotFoundException(String message) {
		super(message);
	}
        
	
	
	
}
