package com.example.demo.Exceptions;

public class BusNotFoundException extends Exception {

	public BusNotFoundException(String message) {
        super(message);
    }
}
