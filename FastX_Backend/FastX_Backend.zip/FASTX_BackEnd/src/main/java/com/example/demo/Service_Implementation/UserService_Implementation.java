	package com.example.demo.Service_Implementation;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;
	
import com.example.demo.DTO.BookingDTO;
import com.example.demo.DTO.UserDTO;
import com.example.demo.Entity.Booking;
import com.example.demo.Entity.Bus;
import com.example.demo.Entity.Route;
import com.example.demo.Entity.Seat;
import com.example.demo.Entity.User;
import com.example.demo.Enum.UserRole;
import com.example.demo.Exceptions.EmailAlreadyExistsException;
import com.example.demo.Exceptions.InvalidCredentialsException;
import com.example.demo.Exceptions.UserNotFoundException;
import com.example.demo.Mappers.BookingMapper;
import com.example.demo.Mappers.UserMapper;
import com.example.demo.Repositories.BookingRepository;
import com.example.demo.Repositories.BusRepository;
import com.example.demo.Repositories.RouteRepository;
import com.example.demo.Repositories.SeatRepository;
import com.example.demo.Repositories.UserRepository;

import com.example.demo.Service.UserService;

@Service
public class UserService_Implementation implements UserService {

	@Autowired
    private UserRepository UserRepo;
	
	@Autowired
    private UserMapper userMapper;
	
	 @Autowired
	    private PasswordEncoder passwordEncoder;
	 
	 
	 @Autowired
	 private BookingRepository bookingRepository;

	@Override
	public UserDTO registerUser(UserDTO userDto) throws EmailAlreadyExistsException {
		if (UserRepo.existsByEmail(userDto.getEmail())) {
            throw new EmailAlreadyExistsException("Email already exists");
        }

        User user = UserMapper.toEntity(userDto);
        user.setPassword(passwordEncoder.encode(user.getPassword())); 
        User saved = UserRepo.save(user);
        return UserMapper.toDTO(saved);
	}

	
	@Override
	public UserDTO login(String email, String password) throws UserNotFoundException, InvalidCredentialsException {
		User user = UserRepo.findByEmail(email);
	    if (user == null) {
	        throw new UserNotFoundException("User not found with email: " + email);
	    }

	    if (!passwordEncoder.matches(password, user.getPassword())) {
	        throw new InvalidCredentialsException("Invalid password");
	    }

	    return UserMapper.toDTO(user);
	}

	@Override
	public UserDTO loginAdmin(String email, String password) throws UserNotFoundException, InvalidCredentialsException {
		 User user = UserRepo.findByEmail(email);
		    if (user == null || user.getRole() != UserRole.ADMIN) {
		        throw new UserNotFoundException("Invalid admin credentials");
		    }
		    if (!passwordEncoder.matches(password, user.getPassword())) {
		        throw new InvalidCredentialsException("Invalid password");
		    }

		    return UserMapper.toDTO(user);
	}

	@Override
	public UserDTO loginOperator(String email, String password) throws UserNotFoundException, InvalidCredentialsException {
		User user = UserRepo.findByEmail(email);
	    if (user == null || user.getRole() != UserRole.OPERATOR) {
	        throw new UserNotFoundException("Invalid operator credentials");
	    }
	    if (!passwordEncoder.matches(password, user.getPassword())) {
	        throw new InvalidCredentialsException("Invalid password");
	    }

	    return UserMapper.toDTO(user);
	}

	
	@Override
	public UserDTO updateUser(int id, UserDTO userDto) throws UserNotFoundException {
		User existing = UserRepo.findById(id).orElse(null);
        if (existing == null) {
            throw new UserNotFoundException("User not found with ID: " + id);
        }

        existing.setUserName(userDto.getUserName());
        existing.setEmail(userDto.getEmail());
        existing.setPhone(userDto.getPhone());
        existing.setAddress(userDto.getAddress());
        existing.setPassword(userDto.getPassword());
        existing.setRole(userDto.getRole());

        User updated = UserRepo.save(existing);
        return UserMapper.toDTO(updated);
	}

	
	@Override
	public String deleteUser(int id) throws UserNotFoundException {
		if (!UserRepo.existsById(id)) {
	        throw new UserNotFoundException("Cannot delete. User not found with ID: " + id);
	    }

	    if (bookingRepository.existsByUserUserId(id)) {
	        throw new IllegalStateException("Cannot delete user with active bookings.");
	    }

	    UserRepo.deleteById(id);
	    return "User deleted successfully";
	}

	@Override
	public UserDTO getUserById(int id) throws UserNotFoundException {
		  User user = UserRepo.findById(id).orElse(null);
	        if (user == null) {
	            throw new UserNotFoundException("User not found with ID: " + id);
	        }
	        return UserMapper.toDTO(user);
	}

	@Override
	public List<UserDTO> getUsersByRole(UserRole role) {
		 List<User> users = UserRepo.findByRole(role);
	        return users.stream()
	                .map(user -> UserMapper.toDTO(user))
	                .collect(Collectors.toList());
	}

	@Override
	public List<UserDTO> getAllUsers() {
		 List<User> users = UserRepo.findAll();
	        return users.stream()
	                .map(user -> UserMapper.toDTO(user))
	                .collect(Collectors.toList());
	}

	@Override
	public UserDTO viewProfile(int userId) throws UserNotFoundException {
		return getUserById(userId);	
	}

	@Override
	public String forgotPassword(String email) throws UserNotFoundException {
		User user = UserRepo.findByEmail(email);
        if (user == null) {
            throw new UserNotFoundException("Email not found: " + email);
        }
        return "Reset password link sent to " + email;
	}

	@Override
	public List<UserDTO> getAllOperators() {
		  List<User> operators = UserRepo.findByRole(UserRole.OPERATOR);
	        return operators.stream()
	                .map(user -> UserMapper.toDTO(user))
	                .collect(Collectors.toList());
	}

	@Override
	public String deleteOperator(int operatorId) throws UserNotFoundException {
		 User operator = UserRepo.findById(operatorId).orElse(null);
	        if (operator == null || operator.getRole() != UserRole.OPERATOR) {
	            throw new UserNotFoundException("Operator not found with ID: " + operatorId);
	        }
	        UserRepo.delete(operator);
	        return "Operator deleted successfully";
	    }
	}
	
	

	


